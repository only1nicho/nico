# Operation Naira — Roadmap

Recommended approach: a browser-native stack (TypeScript + Three.js/WebGL for the game, TanStack Start on Netlify for the site and services). There's no download, it loads instantly on any desktop browser, and one codebase can reach mobile later.

## 1. Playable product surface ✅ (mostly done)
- Branded landing page (`/`) with HD key art, features, arsenal, maps and squad-comms sections.
- Playable 3D training match at `/play`: Oshodi Market map (danfos, stalls, footbridge, containers), 8 weapons, ADS/scopes, recoil, reloads, headshots, AI militia, minimap, kill feed, streak callouts, scoreboard and end-of-match rewards.
- Weapon data, upgrade levels and attachment stats (`src/data/game.ts`) plus a 3D weapon preview component (`src/components/WeaponPreview.tsx`).
- **Remaining:** the `/armory` route page (gunsmith UI that uses `WeaponPreview`, `computeStats` and `statBars`). The site already links to it.

## 2. Accounts and profiles
Netlify Identity sign-up/login, plus a Netlify Database profile: callsign, level, XP and Naira balance.

## 3. Persistent progression
Store owned weapons, levels and attachments, and record match results that award XP/Naira. Swap `PROFILE` fixtures for real data.

## 4. Real-time multiplayer
Authoritative game server over WebSockets (Colyseus or a custom Node server on a dedicated host such as Fly.io; Netlify Functions can't hold long-lived sockets), a client prediction/interpolation layer, matchmaking, and Team Deathmatch and Domination modes.

## 5. Voice and text chat
WebRTC proximity and squad voice (LiveKit or a similar SFU), a Pidgin quick-chat wheel, and mute/report tools.

## 6. More maps
Third Mainland Bridge and Abuja Central District.

## 7. Mobile
Touch controls, performance tiers and a PWA install.

## 8. Live ops
Seasons, battle pass, leaderboards, anti-cheat and analytics.
