# AGENTS.md

Operation Naira is a browser FPS set in Nigeria, built with TanStack Start, Three.js and Tailwind 4 on Netlify. **Continue from [PLAN.md](PLAN.md).**

## Layout
- `src/data/game.ts`: the single source of fixtures and balance (weapons, attachments, `computeStats`, `statBars`, maps, stub `PROFILE`, loadout <-> URL search helpers). A later milestone replaces `PROFILE` and ownership data with Netlify Database.
- `src/game/`: the framework-free engine. `engine.ts` (loop, player, weapons, bots, HUD callbacks), `world.ts` (procedural Oshodi map with merged geometry and AABB colliders), `models.ts` (primitive weapon/soldier/arm models), `textures.ts` (canvas textures), `audio.ts` (synthesised WebAudio).
- `src/components/`: `site.tsx` (header, footer, `img()` Image CDN helper), `GameView.tsx` (HUD and briefing/pause/end overlays around the engine), `WeaponPreview.tsx` (3D gun viewer for the Armory).
- `src/routes/`: `index.tsx` (landing page), `play.tsx` (loadout arrives through search params `p,pl,pa,s,sl,sa`). `/armory` is linked but not built yet.
- `public/img/`: generated PNG art. Always reference it through `img(path, width)`, never directly.

## Conventions
- The engine is imported dynamically on the client only (it touches WebGL and `document`). Keep `src/game` free of React.
- The engine talks to the UI only through `EngineCallbacks`. The HUD is throttled to 15 Hz.
- Colliders are axis-aligned boxes. Builder rotations must be multiples of 90°.
- The theme tokens (`naija`, `gold`, `blood`, `ink`, `panel`, `line`) and the fonts (Anton display, Chakra Petch UI) are defined in `styles.css`.
