import { useEffect, useRef } from 'react'
import type { Weapon } from '@/data/game'

/** Rotatable 3D render of a weapon build, using the same model builder as the in-game viewmodel. */
export function WeaponPreview({ weapon, attachments }: { weapon: Weapon; attachments: string[] }) {
  const ref = useRef<HTMLDivElement>(null)
  const api = useRef<{ set: (w: Weapon, a: string[]) => void } | null>(null)
  const latest = useRef({ weapon, attachments })
  latest.current = { weapon, attachments }

  useEffect(() => {
    let disposed = false
    let cleanup = () => {}
    void Promise.all([import('three'), import('@/game/models')]).then(([THREE, { buildWeaponModel }]) => {
      const el = ref.current
      if (disposed || !el) return
      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
      renderer.setSize(el.clientWidth, el.clientHeight)
      renderer.toneMapping = THREE.ACESFilmicToneMapping
      renderer.outputColorSpace = THREE.SRGBColorSpace
      el.appendChild(renderer.domElement)

      const scene = new THREE.Scene()
      const camera = new THREE.PerspectiveCamera(30, el.clientWidth / el.clientHeight, 0.01, 50)
      camera.position.set(0, 0.25, 2.4)
      camera.lookAt(0, 0, 0)
      scene.add(new THREE.HemisphereLight('#c9d6e8', '#2a1a10', 1.2))
      const key = new THREE.DirectionalLight('#ffd2a0', 3)
      key.position.set(2, 2, 2)
      const rim = new THREE.DirectionalLight('#3ddc84', 2.5)
      rim.position.set(-2, 1, -2)
      const fill = new THREE.DirectionalLight('#ffffff', 0.8)
      fill.position.set(-2, -1, 2)
      scene.add(key, rim, fill)

      const pivot = new THREE.Group()
      scene.add(pivot)
      let current: import('three').Group | null = null
      const set = (w: Weapon, a: string[]) => {
        if (current) {
          pivot.remove(current)
          current.traverse((o) => {
            const m = o as import('three').Mesh
            m.geometry?.dispose()
          })
        }
        const { group } = buildWeaponModel(w, a)
        const box = new THREE.Box3().setFromObject(group)
        const size = box.getSize(new THREE.Vector3())
        const center = box.getCenter(new THREE.Vector3())
        group.position.sub(center)
        const holder = new THREE.Group()
        holder.add(group)
        holder.scale.setScalar(1.25 / Math.max(size.z, 0.3))
        holder.rotation.y = Math.PI / 2
        pivot.add(holder)
        current = holder
      }
      set(latest.current.weapon, latest.current.attachments)
      api.current = { set }

      let dragging = false
      let lastX = 0
      let vel = 0.4
      let rotY = -0.5
      const down = (e: PointerEvent) => {
        dragging = true
        lastX = e.clientX
        el.setPointerCapture(e.pointerId)
      }
      const move = (e: PointerEvent) => {
        if (!dragging) return
        const dx = e.clientX - lastX
        lastX = e.clientX
        rotY += dx * 0.01
        vel = dx * 0.6
      }
      const up = () => (dragging = false)
      el.addEventListener('pointerdown', down)
      el.addEventListener('pointermove', move)
      el.addEventListener('pointerup', up)
      const onResize = () => {
        renderer.setSize(el.clientWidth, el.clientHeight)
        camera.aspect = el.clientWidth / el.clientHeight
        camera.updateProjectionMatrix()
      }
      const ro = new ResizeObserver(onResize)
      ro.observe(el)

      const clock = new THREE.Clock()
      renderer.setAnimationLoop(() => {
        const dt = Math.min(clock.getDelta(), 0.05)
        if (!dragging) {
          vel = THREE.MathUtils.damp(vel, 0.35, 2, dt)
          rotY += vel * dt
        }
        pivot.rotation.y = rotY
        pivot.rotation.x = Math.sin(clock.elapsedTime * 0.6) * 0.06
        renderer.render(scene, camera)
      })

      cleanup = () => {
        renderer.setAnimationLoop(null)
        ro.disconnect()
        el.removeEventListener('pointerdown', down)
        el.removeEventListener('pointermove', move)
        el.removeEventListener('pointerup', up)
        renderer.dispose()
        renderer.domElement.remove()
      }
    })
    return () => {
      disposed = true
      api.current = null
      cleanup()
    }
  }, [])

  useEffect(() => {
    api.current?.set(weapon, attachments)
  }, [weapon, attachments.join(',')])

  return <div ref={ref} className="h-full w-full cursor-grab touch-none active:cursor-grabbing" />
}
