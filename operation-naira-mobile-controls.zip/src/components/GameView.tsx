import { Link } from '@tanstack/react-router'
import { Crosshair, Pause, Skull, Trophy, Wrench } from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import { MAPS, MATCH_KILL_TARGET, PROFILE, computeStats, loadoutToSearch, type Loadout } from '@/data/game'
import type { Difficulty, Engine, HudState, KillEntry, MatchStats } from '@/game/engine'
import { img } from './site'

type Phase = 'briefing' | 'playing' | 'paused' | 'ended'

interface DamageMark {
  id: number
  angle: number
}

const DIFFS: { id: Difficulty; label: string; blurb: string }[] = [
  { id: 'recruit', label: 'Recruit', blurb: 'Six slow hostiles. Learn the market.' },
  { id: 'regular', label: 'Regular', blurb: 'Eight hostiles who shoot back.' },
  { id: 'veteran', label: 'Veteran', blurb: 'Nine sharp-eyed militia. No mercy.' },
]

export function GameView({ loadout }: { loadout: Loadout }) {
  const mountRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<HTMLCanvasElement>(null)
  const engineRef = useRef<Engine | null>(null)
  const [phase, setPhase] = useState<Phase>('briefing')
  const phaseRef = useRef<Phase>('briefing')
  const [difficulty, setDifficulty] = useState<Difficulty>('regular')
  const [session, setSession] = useState(0)
  const [ready, setReady] = useState(false)
  const [hud, setHud] = useState<HudState | null>(null)
  const [hit, setHit] = useState<{ kind: 'body' | 'head' | 'kill'; id: number } | null>(null)
  const [feed, setFeed] = useState<KillEntry[]>([])
  const [damage, setDamage] = useState<DamageMark[]>([])
  const [callout, setCallout] = useState<{ text: string; id: number } | null>(null)
  const [stats, setStats] = useState<MatchStats | null>(null)
  const [sens, setSens] = useState(1)
  const [coarse, setCoarse] = useState(false)

  const primary = computeStats(loadout.primary.id, loadout.primary.level, loadout.primary.attachments)
  const secondary = computeStats(loadout.secondary.id, loadout.secondary.level, loadout.secondary.attachments)

  const setP = (p: Phase) => {
    phaseRef.current = p
    setPhase(p)
  }

  useEffect(() => setCoarse(window.matchMedia('(pointer: coarse)').matches), [])

  useEffect(() => {
    let disposed = false
    let engine: Engine | null = null
    setReady(false)
    void import('@/game/engine').then(({ Engine }) => {
      if (disposed || !mountRef.current || !mapRef.current) return
      engine = new Engine(
        mountRef.current,
        mapRef.current,
        { primary, secondary, difficulty, sensitivity: sens },
        {
          onHud: setHud,
          onHitMarker: (kind) => setHit({ kind, id: Math.random() }),
          onKillFeed: (e) => setFeed((f) => [e, ...f].slice(0, 5)),
          onDamage: (angle) => {
            const id = Math.random()
            setDamage((d) => [...d.slice(-3), { id, angle }])
            setTimeout(() => setDamage((d) => d.filter((x) => x.id !== id)), 1100)
          },
          onLock: (locked) => {
            if (phaseRef.current === 'ended') return
            if (locked) setP('playing')
            else if (phaseRef.current === 'playing') setP('paused')
          },
          onEnd: (s) => {
            setStats(s)
            setP('ended')
          },
          onCallout: (text) => setCallout({ text, id: Math.random() }),
        },
      )
      engineRef.current = engine
      setReady(true)
    })
    return () => {
      disposed = true
      engine?.dispose()
      engineRef.current = null
    }
    // the engine is rebuilt only for a new session or difficulty
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, difficulty])

  useEffect(() => engineRef.current?.setSensitivity(sens), [sens])

  useEffect(() => {
    if (!hit) return
    const t = setTimeout(() => setHit(null), hit.kind === 'kill' ? 320 : 140)
    return () => clearTimeout(t)
  }, [hit])

  const deploy = useCallback(() => engineRef.current?.lock(), [])
  const restart = () => {
    setStats(null)
    setFeed([])
    setHud(null)
    setP('briefing')
    setSession((s) => s + 1)
  }

  const fovHalf = 37.5
  const spreadPx = hud ? Math.min(90, 8 + (hud.spread / Math.tan((fovHalf * Math.PI) / 180)) * 420) : 12
  const showCross = hud && hud.ads < 0.55 && hud.alive
  const lowHealth = hud ? Math.max(0, (60 - hud.health) / 60) : 0
  const mins = hud ? Math.floor(hud.timeLeft / 60) : 5
  const secs = hud ? Math.floor(hud.timeLeft % 60) : 0
  const leader = hud?.board.find((r) => !r.you)

  return (
    <div className="fixed inset-0 select-none overflow-hidden bg-black font-ui text-white">
      <div ref={mountRef} className="absolute inset-0" onClick={() => phase === 'playing' && deploy()} />

      {/* ---------- HUD ---------- */}
      <div className={`pointer-events-none absolute inset-0 transition-opacity ${phase === 'briefing' ? 'opacity-0' : 'opacity-100'}`}>
        {/* low-health vignette */}
        <div
          className={`absolute inset-0 ${lowHealth > 0.4 ? 'low-health' : ''}`}
          style={{ background: 'radial-gradient(ellipse at center, transparent 45%, rgba(170,0,0,0.85) 100%)', opacity: lowHealth }}
        />

        {/* scope */}
        {hud?.scoped && (
          <div className="absolute inset-0">
            <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at center, transparent 0, transparent 34vh, rgba(0,0,0,0.6) 34.5vh, #000 35.5vh)' }} />
            <div className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-black/80" />
            <div className="absolute left-0 top-1/2 h-px w-full -translate-y-1/2 bg-black/80" />
            <div className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-red-500" />
          </div>
        )}

        {/* crosshair */}
        {showCross && (
          <div className="absolute left-1/2 top-1/2">
            {[0, 90, 180, 270].map((r) => (
              <div key={r} className="absolute left-0 top-0" style={{ transform: `rotate(${r}deg)` }}>
                <div className="absolute h-[2px] w-3 -translate-y-1/2 bg-white shadow-[0_0_2px_#000]" style={{ left: spreadPx }} />
              </div>
            ))}
            <div className="absolute h-[3px] w-[3px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/90" />
          </div>
        )}
        {hud && hud.ads > 0.8 && !hud.scoped && primary.optic && hud.slot === 0 && (
          <div className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-red-500 shadow-[0_0_6px_#f00]" />
        )}

        {/* hit marker */}
        {hit && (
          <div key={hit.id} className="absolute left-1/2 top-1/2">
            {[45, 135, 225, 315].map((r) => (
              <div key={r} className="absolute left-0 top-0" style={{ transform: `rotate(${r}deg)` }}>
                <div
                  className={`absolute h-[2.5px] -translate-y-1/2 ${hit.kind === 'kill' ? 'w-4 bg-blood' : hit.kind === 'head' ? 'w-3.5 bg-gold' : 'w-3 bg-white'}`}
                  style={{ left: 7 }}
                />
              </div>
            ))}
          </div>
        )}

        {/* damage direction */}
        {damage.map((d) => (
          <div key={d.id} className="absolute left-1/2 top-1/2 h-0 w-0" style={{ transform: `rotate(${(-d.angle * 180) / Math.PI}deg)` }}>
            <div className="feed-in absolute -left-16 -top-[150px] h-6 w-32 rounded-[50%] border-t-4 border-blood/90 blur-[1px]" />
          </div>
        ))}

        {/* reload */}
        {hud && hud.reloading > 0 && (
          <div className="absolute left-1/2 top-[58%] w-40 -translate-x-1/2 text-center">
            <div className="text-[11px] font-bold tracking-[0.3em] text-white/80">RELOADING</div>
            <div className="mt-1 h-1 bg-white/20">
              <div className="h-full bg-gold" style={{ width: `${hud.reloading * 100}%` }} />
            </div>
          </div>
        )}
        {hud && hud.alive && hud.ammo === 0 && hud.reloading === 0 && (
          <div className="absolute left-1/2 top-[58%] -translate-x-1/2 text-xs font-bold tracking-[0.3em] text-blood">{hud.reserve > 0 ? 'PRESS R TO RELOAD' : 'NO AMMO · PRESS 2'}</div>
        )}

        {/* minimap */}
        <div className="absolute left-5 top-5">
          <canvas ref={mapRef} width={360} height={360} className="h-[180px] w-[180px]" />
          <div className="mt-2 text-center text-[10px] font-bold tracking-[0.3em] text-white/60">OSHODI MARKET</div>
        </div>

        {/* score */}
        <div className="absolute left-1/2 top-5 -translate-x-1/2 text-center">
          <div className="flex items-stretch gap-px bg-black/40 backdrop-blur-sm">
            <div className="bg-naija/80 px-4 py-1.5">
              <div className="text-[10px] font-bold tracking-widest text-white/80">YOU</div>
              <div className="font-display text-2xl leading-none">{hud?.kills ?? 0}</div>
            </div>
            <div className="px-5 py-1.5">
              <div className="text-[10px] font-bold tracking-widest text-white/60">FIRST TO {MATCH_KILL_TARGET}</div>
              <div className="font-display text-2xl leading-none tabular-nums">
                {mins}:{String(secs).padStart(2, '0')}
              </div>
            </div>
            <div className="bg-blood/70 px-4 py-1.5">
              <div className="max-w-[90px] truncate text-[10px] font-bold tracking-widest text-white/80">{leader?.name.toUpperCase() ?? 'LEADER'}</div>
              <div className="font-display text-2xl leading-none">{leader?.kills ?? 0}</div>
            </div>
          </div>
          <div className="mt-1 text-[11px] font-semibold tracking-widest text-gold">{hud?.score ?? 0} PTS</div>
        </div>

        {/* kill feed */}
        <div className="absolute right-5 top-5 flex w-80 flex-col items-end gap-1.5">
          {feed.map((k) => (
            <div key={k.id} className="feed-in flex items-center gap-2 bg-black/45 px-3 py-1 text-sm backdrop-blur-sm">
              <span className={k.you === 'killer' ? 'font-bold text-naija-bright' : 'text-blood'}>{k.killer}</span>
              <span className="text-[10px] uppercase tracking-wider text-white/50">[{k.weapon}]</span>
              {k.headshot && <Crosshair className="h-3.5 w-3.5 text-gold" />}
              <span className={k.you === 'victim' ? 'font-bold text-naija-bright' : 'text-blood'}>{k.victim}</span>
            </div>
          ))}
        </div>

        {/* callout */}
        {callout && (
          <div key={callout.id} className="callout absolute left-1/2 top-[22%] -translate-x-1/2 whitespace-nowrap font-display text-4xl tracking-wide text-gold drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
            {callout.text}
          </div>
        )}

        {/* health */}
        <div className="absolute bottom-6 left-6 w-72">
          <div className="flex items-end justify-between">
            <div>
              <div className="text-[10px] font-bold tracking-[0.3em] text-white/50">{PROFILE.rank.toUpperCase()}</div>
              <div className="font-display text-xl leading-none">{PROFILE.callsign}</div>
            </div>
            <div className="font-display text-3xl leading-none tabular-nums">{hud?.health ?? 100}</div>
          </div>
          <div className="mt-2 h-2 skew-x-[-20deg] bg-white/15">
            <div
              className={`h-full transition-[width] duration-150 ${(hud?.health ?? 100) < 35 ? 'bg-blood' : 'bg-naija-bright'}`}
              style={{ width: `${hud?.health ?? 100}%` }}
            />
          </div>
          {hud && hud.streak >= 2 && <div className="mt-2 text-xs font-bold tracking-widest text-gold">{hud.streak} KILL STREAK</div>}
        </div>

        {/* weapon */}
        <div className="absolute bottom-6 right-6 text-right">
          <div className="flex justify-end gap-1.5">
            {[primary, secondary].map((w, i) => (
              <div key={w.id} className={`px-2 py-0.5 text-[10px] font-bold tracking-widest ${hud?.slot === i ? 'bg-gold text-ink' : 'bg-white/10 text-white/50'}`}>
                {i + 1} · {w.nickname.toUpperCase()}
              </div>
            ))}
          </div>
          <div className="mt-2 flex items-baseline justify-end gap-2">
            <span className={`font-display text-6xl leading-none tabular-nums ${hud && hud.ammo <= Math.ceil(hud.mag * 0.25) ? 'text-blood' : ''}`}>{hud?.ammo ?? primary.mag}</span>
            <span className="font-display text-2xl text-white/50 tabular-nums">/ {hud?.reserve ?? primary.reserve}</span>
          </div>
          <div className="text-sm font-semibold tracking-wider text-white/70">
            {hud?.weaponName ?? primary.name} <span className="text-gold">"{hud?.weaponNick ?? primary.nickname}"</span>
          </div>
        </div>

        {/* death */}
        {hud && !hud.alive && phase !== 'ended' && (
          <div className="absolute inset-0 grid place-items-center bg-blood/20">
            <div className="text-center">
              <Skull className="mx-auto h-12 w-12 text-blood" />
              <div className="mt-3 font-display text-6xl tracking-wide">YOU DON FALL</div>
              <div className="mt-2 text-white/70">{feed.find((f) => f.you === 'victim')?.killer ?? 'A hostile'} got you. Redeploying…</div>
              <div className="mt-4 font-display text-4xl text-gold tabular-nums">{Math.ceil(hud.respawnIn)}</div>
            </div>
          </div>
        )}

        {/* scoreboard */}
        {hud?.showBoard && <Scoreboard rows={hud.board} />}
      </div>

      {/* ---------- MOBILE TOUCH CONTROLS ---------- */}
      {coarse && phase === 'playing' && (
        <div className="pointer-events-none absolute inset-0 z-30 select-none" style={{ touchAction: 'none' }}>
          <div
            className="pointer-events-auto absolute bottom-8 left-5 flex h-32 w-32 items-center justify-center rounded-full border-2 border-white/35 bg-black/25"
            style={{ touchAction: 'none' }}
            onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); const r = e.currentTarget.getBoundingClientRect(); const x = (e.clientX - (r.left + r.width / 2)) / (r.width * 0.34); const y = (e.clientY - (r.top + r.height / 2)) / (r.height * 0.34); engineRef.current?.setTouchMove(x, y) }}
            onPointerMove={(e) => { if (e.buttons === 0 && e.pressure === 0) return; const r = e.currentTarget.getBoundingClientRect(); const x = (e.clientX - (r.left + r.width / 2)) / (r.width * 0.34); const y = (e.clientY - (r.top + r.height / 2)) / (r.height * 0.34); engineRef.current?.setTouchMove(x, y) }}
            onPointerUp={() => engineRef.current?.setTouchMove(0, 0)}
            onPointerCancel={() => engineRef.current?.setTouchMove(0, 0)}
          >
            <div className="pointer-events-none flex h-12 w-12 items-center justify-center rounded-full border border-white/70 bg-white/25 text-[9px] font-black tracking-widest">MOVE</div>
          </div>
          <div
            className="pointer-events-auto absolute bottom-4 right-24 top-24 w-[38%] rounded-3xl"
            style={{ touchAction: 'none' }}
            onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); e.currentTarget.dataset.lastX = String(e.clientX); e.currentTarget.dataset.lastY = String(e.clientY) }}
            onPointerMove={(e) => { if (!e.currentTarget.hasPointerCapture(e.pointerId)) return; const lx = Number(e.currentTarget.dataset.lastX ?? e.clientX); const ly = Number(e.currentTarget.dataset.lastY ?? e.clientY); engineRef.current?.touchLook(e.clientX - lx, e.clientY - ly); e.currentTarget.dataset.lastX = String(e.clientX); e.currentTarget.dataset.lastY = String(e.clientY) }}
          />
          <div className="pointer-events-auto absolute bottom-7 right-4 flex flex-col gap-2">
            <button aria-label="Fire" className="h-16 w-16 rounded-full border-2 border-blood bg-blood/80 text-xs font-black tracking-widest shadow-lg active:scale-95" style={{ touchAction: 'none' }} onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); engineRef.current?.setTouchFire(true) }} onPointerUp={() => engineRef.current?.setTouchFire(false)} onPointerCancel={() => engineRef.current?.setTouchFire(false)} onLostPointerCapture={() => engineRef.current?.setTouchFire(false)}>FIRE</button>
            <button aria-label="Aim down sights" className="h-12 w-16 rounded-xl border border-white/50 bg-black/65 text-[10px] font-bold" style={{ touchAction: 'none' }} onPointerDown={(e) => { e.preventDefault(); engineRef.current?.setTouchAim(true) }} onPointerUp={() => engineRef.current?.setTouchAim(false)} onPointerCancel={() => engineRef.current?.setTouchAim(false)}>AIM</button>
          </div>
          <div className="pointer-events-auto absolute bottom-8 right-28 flex gap-2">
            <button className="h-11 rounded-lg border border-white/40 bg-black/70 px-3 text-[10px] font-bold" onClick={() => engineRef.current?.touchReload()}>RELOAD</button>
            <button className="h-11 rounded-lg border border-white/40 bg-black/70 px-3 text-[10px] font-bold" onClick={() => engineRef.current?.touchSwitch()}>SWAP</button>
            <button className="h-11 rounded-lg border border-white/40 bg-black/70 px-3 text-[10px] font-bold" onClick={() => engineRef.current?.touchJump()}>JUMP</button>
          </div>
        </div>
      )}

      {/* ---------- BRIEFING ---------- */}
      {phase === 'briefing' && (
        <div className="absolute inset-0 overflow-y-auto">
          <img src={img(MAPS[0].image, 1920)} alt="" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/85 to-ink/30" />
          <div className="relative mx-auto flex min-h-full max-w-7xl flex-col justify-center px-6 py-12">
            <Link to="/" className="mb-8 text-xs font-bold uppercase tracking-[0.3em] text-white/50 hover:text-white">
              ← Operation Naira
            </Link>
            <div className="text-xs font-bold uppercase tracking-[0.35em] text-naija-bright">Training operation · Lagos</div>
            <h1 className="mt-3 font-display text-[clamp(3rem,8vw,6.5rem)] leading-[0.9]">OSHODI MARKET</h1>
            <p className="mt-4 max-w-xl text-white/75">
              The Black Market Syndicate has taken the market under the footbridge. Clear the stalls, use the danfos for cover and be the
              first to {MATCH_KILL_TARGET} eliminations before the five-minute clock runs out.
            </p>

            <div className="mt-8 grid max-w-3xl gap-3 sm:grid-cols-3">
              {DIFFS.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setDifficulty(d.id)}
                  className={`clip-corner border p-4 text-left transition ${difficulty === d.id ? 'border-gold bg-gold/10' : 'border-white/15 bg-black/30 hover:border-white/40'}`}
                >
                  <div className={`font-display text-xl ${difficulty === d.id ? 'text-gold' : ''}`}>{d.label.toUpperCase()}</div>
                  <div className="mt-1 text-xs text-white/60">{d.blurb}</div>
                </button>
              ))}
            </div>

            <div className="mt-6 flex max-w-3xl flex-wrap items-center gap-4 border border-white/10 bg-black/40 p-4">
              <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/50">Loadout</div>
              {[primary, secondary].map((w) => (
                <div key={w.id} className="text-sm">
                  <span className="font-semibold">{w.name}</span> <span className="text-gold">"{w.nickname}"</span>
                  <span className="ml-1 text-white/50">Lv{w.level}{w.attachments.length ? ` · ${w.attachments.length} att.` : ''}</span>
                </div>
              ))}
              <Link to="/armory" search={loadoutToSearch(loadout)} className="ml-auto flex items-center gap-2 text-sm font-semibold text-gold hover:text-white">
                <Wrench className="h-4 w-4" /> Change
              </Link>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-6">
              <button
                onClick={deploy}
                disabled={!ready}
                className="clip-corner bg-gold px-10 py-4 font-display text-2xl tracking-wider text-ink transition hover:bg-white disabled:cursor-wait disabled:opacity-60"
              >
                {ready ? 'DEPLOY' : 'LOADING MAP…'}
              </button>
              <Controls />
            </div>
            {coarse && (
              <p className="mt-6 max-w-xl border-l-2 border-gold pl-3 text-sm text-white/70">
                Touch controls are coming in the mobile update. For now, play on a desktop or laptop with a mouse and keyboard.
              </p>
            )}
          </div>
        </div>
      )}

      {/* ---------- PAUSE ---------- */}
      {phase === 'paused' && (
        <div className="absolute inset-0 grid place-items-center bg-ink/75 backdrop-blur-sm">
          <div className="w-full max-w-md p-6 text-center">
            <Pause className="mx-auto h-10 w-10 text-gold" />
            <div className="mt-3 font-display text-5xl">PAUSED</div>
            <button onClick={deploy} className="clip-corner mt-8 w-full bg-gold py-4 font-display text-xl tracking-wider text-ink hover:bg-white">
              RESUME
            </button>
            <label className="mt-6 block text-left text-xs font-bold uppercase tracking-widest text-white/60">
              Mouse sensitivity · {sens.toFixed(2)}
              <input type="range" min={0.3} max={2.5} step={0.05} value={sens} onChange={(e) => setSens(Number(e.target.value))} className="mt-2 w-full accent-[#f2c200]" />
            </label>
            <div className="mt-6 grid grid-cols-2 gap-3">
              <button onClick={restart} className="border border-white/20 py-3 text-sm font-semibold uppercase tracking-widest hover:border-white">
                Restart
              </button>
              <Link to="/" className="border border-white/20 py-3 text-sm font-semibold uppercase tracking-widest hover:border-white">
                Quit
              </Link>
            </div>
            <div className="mt-6 flex justify-center">
              <Controls />
            </div>
          </div>
        </div>
      )}

      {/* ---------- END ---------- */}
      {phase === 'ended' && stats && (
        <div className="absolute inset-0 overflow-y-auto bg-ink/85 backdrop-blur-md">
          <div className="mx-auto flex min-h-full max-w-3xl flex-col justify-center px-6 py-12">
            <Trophy className={`h-12 w-12 ${stats.placement === 1 ? 'text-gold' : 'text-white/50'}`} />
            <div className="mt-3 text-xs font-bold uppercase tracking-[0.35em] text-naija-bright">Match complete · Oshodi Market</div>
            <h2 className="mt-2 font-display text-6xl">{stats.placement === 1 ? 'MARKET SECURED' : `FINISHED #${stats.placement} OF ${stats.players}`}</h2>
            <div className="mt-8 grid grid-cols-2 gap-px bg-white/10 sm:grid-cols-4">
              {[
                ['Kills', stats.kills],
                ['Deaths', stats.deaths],
                ['K/D', (stats.kills / Math.max(1, stats.deaths)).toFixed(2)],
                ['Accuracy', `${stats.accuracy}%`],
                ['Headshots', stats.headshots],
                ['Best streak', stats.bestStreak],
                ['Score', stats.score],
                ['Time', `${Math.floor(stats.seconds / 60)}:${String(stats.seconds % 60).padStart(2, '0')}`],
              ].map(([l, v]) => (
                <div key={l} className="bg-panel p-4">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-white/50">{l}</div>
                  <div className="font-display text-3xl">{v}</div>
                </div>
              ))}
            </div>
            <div className="mt-6 flex flex-wrap gap-6 border border-gold/40 bg-gold/5 p-5">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/50">Naira earned</div>
                <div className="font-display text-4xl text-gold">₦{stats.naira.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/50">XP</div>
                <div className="font-display text-4xl">+{stats.xp.toLocaleString()}</div>
              </div>
              <p className="ml-auto max-w-[220px] self-center text-xs text-white/50">Spend Naira in the Armory to level up weapons and unlock attachments.</p>
            </div>
            <div className="mt-8 flex flex-wrap gap-4">
              <button onClick={restart} className="clip-corner bg-gold px-8 py-4 font-display text-xl tracking-wider text-ink hover:bg-white">
                PLAY AGAIN
              </button>
              <Link to="/armory" search={loadoutToSearch(loadout)} className="clip-corner flex items-center gap-2 border border-white/25 px-8 py-4 font-display text-xl tracking-wider hover:border-gold hover:text-gold">
                <Wrench className="h-5 w-5" /> ARMORY
              </Link>
            </div>
            <div className="mt-10">
              <Scoreboard rows={[...(hud?.board ?? [])]} inline />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function Controls() {
  const keys: [string, string][] = [
    ['WASD', 'Move'],
    ['Mouse', 'Aim / Fire'],
    ['RMB', 'Aim down sights'],
    ['Shift', 'Sprint'],
    ['Space', 'Jump'],
    ['C', 'Crouch'],
    ['R', 'Reload'],
    ['1 / 2 / Q', 'Swap'],
    ['Tab', 'Scores'],
    ['Esc', 'Pause'],
  ]
  return (
    <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-xs sm:grid-cols-5">
      {keys.map(([k, v]) => (
        <div key={k} className="flex items-center gap-2">
          <kbd className="min-w-[2rem] border border-white/20 bg-white/5 px-1.5 py-0.5 text-center font-ui text-[10px] font-bold text-white">{k}</kbd>
          <span className="text-white/60">{v}</span>
        </div>
      ))}
    </div>
  )
}

function Scoreboard({ rows, inline = false }: { rows: HudState['board']; inline?: boolean }) {
  return (
    <div className={inline ? '' : 'absolute inset-0 grid place-items-center bg-black/40'}>
      <div className={`w-full max-w-lg ${inline ? '' : 'bg-ink/90 p-6 backdrop-blur'}`}>
        <div className="mb-3 flex justify-between text-[10px] font-bold uppercase tracking-[0.3em] text-white/50">
          <span>Free-for-all · Oshodi</span>
          <span>K / D</span>
        </div>
        {rows.map((r, i) => (
          <div key={r.name} className={`flex items-center justify-between border-b border-white/5 px-3 py-2 text-sm ${r.you ? 'bg-naija/25 font-bold text-naija-bright' : ''}`}>
            <span>
              <span className="mr-3 inline-block w-4 text-white/40">{i + 1}</span>
              {r.name}
            </span>
            <span className="tabular-nums">
              {r.kills} / {r.deaths}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
