import { Link } from '@tanstack/react-router'
import { Crosshair } from 'lucide-react'
import { PROFILE } from '@/data/game'

/** Netlify Image CDN URL for a generated asset in /public/img. */
export function img(path: string, w: number) {
  return `/.netlify/images?url=${encodeURIComponent(`${path}.png`)}&w=${w}&fm=webp&q=78`
}

export function Logo({ className = '' }: { className?: string }) {
  return (
    <Link to="/" className={`flex items-center gap-2.5 ${className}`}>
      <span className="relative grid h-9 w-9 place-items-center bg-naija clip-corner">
        <Crosshair className="h-5 w-5 text-white" strokeWidth={2.5} />
      </span>
      <span className="leading-none">
        <span className="block font-display text-xl tracking-wide text-white">OPERATION NAIRA</span>
        <span className="block text-[10px] font-semibold tracking-[0.35em] text-naija-bright">TACTICAL · LAGOS</span>
      </span>
    </Link>
  )
}

export function SiteHeader() {
  const nav = 'text-sm font-semibold uppercase tracking-widest text-white/70 hover:text-white transition-colors'
  return (
    <header className="fixed inset-x-0 top-0 z-40 border-b border-white/5 bg-ink/70 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5">
        <Logo />
        <nav className="hidden items-center gap-8 md:flex">
          <a href="/#features" className={nav}>
            Features
          </a>
          <a href="/#maps" className={nav}>
            Maps
          </a>
          <Link to="/armory" className={nav} activeProps={{ className: '!text-gold' }}>
            Armory
          </Link>
        </nav>
        <div className="flex items-center gap-4">
          <div className="hidden text-right sm:block">
            <div className="text-xs font-bold text-white">{PROFILE.callsign}</div>
            <div className="text-[11px] text-gold">₦{PROFILE.naira.toLocaleString()}</div>
          </div>
          <Link
            to="/play"
            className="clip-corner bg-gold px-5 py-2.5 font-display text-sm tracking-wider text-ink transition hover:bg-white"
          >
            PLAY NOW
          </Link>
        </div>
      </div>
    </header>
  )
}

export function SiteFooter() {
  return (
    <footer className="border-t border-line bg-ink">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 py-10 md:flex-row md:items-center md:justify-between">
        <Logo />
        <p className="max-w-md text-xs leading-relaxed text-white/40">
          Operation Naira is a work of fiction. Characters, factions and events are invented; locations are inspired by real places in
          Nigeria. Built for the browser — no download required.
        </p>
        <div className="flex gap-1">
          <span className="h-6 w-4 bg-naija" />
          <span className="h-6 w-4 bg-white" />
          <span className="h-6 w-4 bg-naija" />
        </div>
      </div>
    </footer>
  )
}
