import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowRight, Crosshair, Headphones, MapPin, Mic, Shield, Swords, Users, Wrench } from 'lucide-react'
import { MAPS, PROFILE, WEAPONS } from '@/data/game'
import { SiteFooter, SiteHeader, img } from '@/components/site'

export const Route = createFileRoute('/')({
  component: Home,
})

const FEATURES = [
  {
    icon: MapPin,
    title: 'Nigerian battlegrounds',
    body: 'Fight through Oshodi Market, across Third Mainland Bridge and under Aso Rock. Danfos, zinc roofs, generator smoke and harmattan haze, all rebuilt for combat.',
    tag: 'Oshodi playable now',
  },
  {
    icon: Users,
    title: 'Real players, real time',
    body: 'Team Deathmatch, Domination and Search & Destroy against real opponents across Lagos, Abuja, Accra and beyond, with skill-based matchmaking and low-latency servers.',
    tag: 'Online beta in development',
  },
  {
    icon: Wrench,
    title: 'Gunsmith & upgrades',
    body: 'Level up the DICON OBJ-006 and the rest of your arsenal. Fit optics, suppressors, barrels and mags, then take every build straight into a match.',
    tag: 'Armory live',
  },
  {
    icon: Headphones,
    title: 'Real conversations',
    body: 'Proximity voice chat, squad channels and a Pidgin quick-chat wheel. "Oya move!" "Enemy dey come!" Talk like you do with your guys.',
    tag: 'Voice in development',
  },
]

const QUICK_CHAT = ['Oya, move!', 'Enemy dey come!', 'I don cover you', 'Reload, cover me!', 'Na me get this one', 'Well done o!']

function Home() {
  const featured = WEAPONS.filter((w) => ['obj006', 'tavor', 'dragunov', 'pkm'].includes(w.id))
  return (
    <div className="min-h-screen bg-ink">
      <SiteHeader />

      {/* HERO */}
      <section className="grain relative flex min-h-[100svh] items-end overflow-hidden">
        <img
          src={img('/img/hero', 1920)}
          srcSet={`${img('/img/hero', 960)} 960w, ${img('/img/hero', 1600)} 1600w, ${img('/img/hero', 2400)} 2400w`}
          sizes="100vw"
          alt="Nigerian special forces advancing through a smoky Lagos street"
          className="absolute inset-0 h-full w-full object-cover object-[60%_center]"
          fetchPriority="high"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/50 to-ink/10" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/90 via-ink/30 to-transparent" />
        <div className="relative mx-auto w-full max-w-7xl px-5 pb-20 pt-32 md:pb-28">
          <div className="rise flex flex-wrap items-center gap-3 text-xs font-bold uppercase tracking-[0.3em]">
            <span className="bg-naija px-2.5 py-1 text-white">Season 1 · Harmattan</span>
            <span className="text-white/70">Early access · Free in your browser</span>
          </div>
          <h1 className="rise mt-6 font-display text-[clamp(3.5rem,11vw,9.5rem)] leading-[0.85] tracking-tight text-white [animation-delay:80ms]">
            OPERATION
            <br />
            <span className="text-gold">NAIRA</span>
          </h1>
          <p className="rise mt-6 max-w-xl text-lg leading-relaxed text-white/80 [animation-delay:160ms]">
            A tactical first-person shooter set in Nigeria. Hold Oshodi Market against the Black Market Syndicate, upgrade Nigerian-made
            weapons and squad up with real players from Lagos to Abuja.
          </p>
          <div className="rise mt-9 flex flex-wrap gap-4 [animation-delay:240ms]">
            <Link to="/play" className="clip-corner group flex items-center gap-3 bg-gold px-8 py-4 font-display text-lg tracking-wider text-ink transition hover:bg-white">
              <Crosshair className="h-5 w-5" /> DEPLOY TO OSHODI
              <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
            </Link>
            <Link to="/armory" className="clip-corner flex items-center gap-3 border border-white/25 bg-white/5 px-8 py-4 font-display text-lg tracking-wider text-white backdrop-blur transition hover:border-gold hover:text-gold">
              <Wrench className="h-5 w-5" /> OPEN ARMORY
            </Link>
          </div>
          <div className="rise mt-12 grid max-w-2xl grid-cols-3 gap-px bg-white/10 [animation-delay:320ms]">
            {[
              ['8', 'weapons'],
              ['11', 'attachments'],
              ['3', 'Nigerian maps'],
            ].map(([n, l]) => (
              <div key={l} className="bg-ink/70 px-5 py-4 backdrop-blur">
                <div className="font-display text-3xl text-white">{n}</div>
                <div className="text-xs uppercase tracking-widest text-white/50">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="relative border-t border-line bg-panel py-24">
        <div className="mx-auto max-w-7xl px-5">
          <SectionTitle kicker="Built for Naija" title="Commercial-grade combat, rooted at home" />
          <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((f) => (
              <article key={f.title} className="clip-corner group relative border border-line bg-ink p-7 transition hover:border-naija">
                <f.icon className="h-8 w-8 text-naija-bright" />
                <h3 className="mt-5 font-display text-2xl tracking-wide text-white">{f.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-white/60">{f.body}</p>
                <div className="mt-6 text-[11px] font-bold uppercase tracking-[0.2em] text-gold">{f.tag}</div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ARSENAL */}
      <section className="relative overflow-hidden py-24">
        <div className="pointer-events-none absolute -right-20 top-10 select-none font-display text-[18rem] leading-none text-white/[0.025]">OGUN</div>
        <div className="mx-auto max-w-7xl px-5">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionTitle kicker="The arsenal" title="From Kaduna's forges to your hands" />
            <Link to="/armory" className="flex items-center gap-2 font-semibold uppercase tracking-widest text-gold hover:text-white">
              Customise in the Armory <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {featured.map((w) => (
              <Link
                key={w.id}
                to="/armory"
                search={{ w: w.id }}
                className="clip-corner group block border border-line bg-panel p-6 transition hover:-translate-y-1 hover:border-gold"
              >
                <div className="text-[11px] font-bold uppercase tracking-[0.25em] text-white/40">{w.class === 'ar' ? 'Assault rifle' : w.class === 'lmg' ? 'Light machine gun' : w.class === 'sniper' ? 'Marksman' : w.class}</div>
                <div className="mt-3 font-display text-3xl text-white">"{w.nickname}"</div>
                <div className="text-sm text-white/60">{w.name}</div>
                <div className="mt-5 space-y-2">
                  <MiniBar label="DMG" v={w.damage} max={100} />
                  <MiniBar label="RPM" v={w.rpm} max={950} />
                  <MiniBar label="RNG" v={w.range} max={120} />
                </div>
                <div className="mt-5 text-xs text-naija-bright">{w.origin}</div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* MAPS */}
      <section id="maps" className="border-t border-line bg-panel py-24">
        <div className="mx-auto max-w-7xl px-5">
          <SectionTitle kicker="Battlegrounds" title="Every street, a story" />
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {MAPS.map((m, i) => (
              <article key={m.id} className={`group relative overflow-hidden border border-line ${i === 0 ? 'lg:col-span-2 lg:row-span-2' : ''}`}>
                <img
                  src={img(m.image, i === 0 ? 1400 : 800)}
                  alt={`${m.name}, ${m.city}`}
                  loading="lazy"
                  className={`w-full object-cover transition duration-700 group-hover:scale-105 ${i === 0 ? 'h-[420px] lg:h-full' : 'h-[260px]'}`}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6">
                  <div className="flex items-center gap-3">
                    <span className={`px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest ${m.status === 'playable' ? 'bg-naija text-white' : 'bg-white/15 text-white/80'}`}>
                      {m.status === 'playable' ? 'Playable now' : 'Online beta'}
                    </span>
                    <span className="text-xs uppercase tracking-widest text-white/60">{m.city}</span>
                  </div>
                  <h3 className={`mt-2 font-display text-white ${i === 0 ? 'text-5xl' : 'text-3xl'}`}>{m.name}</h3>
                  <p className="mt-2 max-w-lg text-sm text-white/70">{m.blurb}</p>
                  {m.status === 'playable' && (
                    <Link to="/play" className="mt-4 inline-flex items-center gap-2 font-semibold uppercase tracking-widest text-gold hover:text-white">
                      Drop in <ArrowRight className="h-4 w-4" />
                    </Link>
                  )}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* COMMS */}
      <section className="py-24">
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 lg:grid-cols-2">
          <div>
            <SectionTitle kicker="Squad comms" title="Talk your talk" />
            <p className="mt-6 max-w-lg leading-relaxed text-white/65">
              Proximity voice means enemies around the corner can hear you too. Squad channels keep your crew on the same page, and the
              quick-chat wheel speaks Pidgin, Yoruba, Igbo and Hausa callouts when you're too busy to talk.
            </p>
            <ul className="mt-8 space-y-3 text-sm text-white/75">
              <li className="flex items-center gap-3">
                <Mic className="h-4 w-4 text-naija-bright" /> Push-to-talk and open mic with noise suppression
              </li>
              <li className="flex items-center gap-3">
                <Shield className="h-4 w-4 text-naija-bright" /> One-tap mute and report to keep lobbies respectful
              </li>
              <li className="flex items-center gap-3">
                <Swords className="h-4 w-4 text-naija-bright" /> Party up with friends and queue together
              </li>
            </ul>
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="clip-corner border border-line bg-panel p-6">
              <div className="text-[11px] font-bold uppercase tracking-[0.25em] text-white/40">Your squad</div>
              <div className="mt-4 space-y-3">
                {[{ name: PROFILE.callsign, status: 'You · Lvl ' + PROFILE.level, level: PROFILE.level }, ...PROFILE.squad].map((m, i) => (
                  <div key={m.name} className="flex items-center gap-3">
                    <div className={`grid h-9 w-9 place-items-center font-display text-sm ${i === 0 ? 'bg-gold text-ink' : 'bg-naija/30 text-naija-bright'}`}>{m.name[0]}</div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-semibold text-white">{m.name}</div>
                      <div className="text-xs text-white/45">{m.status}</div>
                    </div>
                    {i === 1 && <Mic className="h-4 w-4 animate-pulse text-naija-bright" />}
                  </div>
                ))}
              </div>
            </div>
            <div className="clip-corner border border-line bg-panel p-6">
              <div className="text-[11px] font-bold uppercase tracking-[0.25em] text-white/40">Quick chat</div>
              <div className="mt-4 flex flex-wrap gap-2">
                {QUICK_CHAT.map((q) => (
                  <span key={q} className="border border-white/10 bg-ink px-3 py-1.5 text-sm text-white/85">
                    {q}
                  </span>
                ))}
              </div>
              <div className="mt-6 border-l-2 border-naija pl-3 text-sm">
                <span className="font-semibold text-naija-bright">Chioma_Fire:</span> <span className="text-white/80">Two dey for bridge, I go flank left</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden border-t border-line">
        <img src={img('/img/map-bridge', 1600)} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-ink/40" />
        <div className="relative mx-auto max-w-7xl px-5 py-24">
          <h2 className="font-display text-[clamp(2.5rem,6vw,5rem)] leading-none text-white">
            OYA, SOLDIER.
            <br />
            <span className="text-gold">THE MARKET NO GO HOLD ITSELF.</span>
          </h2>
          <p className="mt-5 max-w-lg text-white/70">No download. Works in Chrome, Edge and Firefox on desktop. Click, lock in, and fight.</p>
          <div className="mt-8 flex flex-wrap gap-4">
            <Link to="/play" className="clip-corner bg-gold px-8 py-4 font-display text-lg tracking-wider text-ink transition hover:bg-white">
              PLAY TRAINING NOW
            </Link>
          </div>
          <div className="mt-10 flex flex-wrap gap-x-6 gap-y-2 text-xs uppercase tracking-widest text-white/45">
            <span>WASD move</span>
            <span>Mouse aim</span>
            <span>Click fire</span>
            <span>Right-click ADS</span>
            <span>R reload</span>
            <span>Shift sprint</span>
            <span>C crouch</span>
            <span>1 / 2 swap</span>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  )
}

function SectionTitle({ kicker, title }: { kicker: string; title: string }) {
  return (
    <div>
      <div className="flex items-center gap-3 text-xs font-bold uppercase tracking-[0.35em] text-naija-bright">
        <span className="h-px w-8 bg-naija-bright" />
        {kicker}
      </div>
      <h2 className="mt-4 font-display text-[clamp(2.2rem,4.5vw,3.75rem)] leading-[0.95] text-white">{title}</h2>
    </div>
  )
}

function MiniBar({ label, v, max }: { label: string; v: number; max: number }) {
  return (
    <div className="flex items-center gap-3 text-[10px] font-bold tracking-widest text-white/40">
      <span className="w-8">{label}</span>
      <div className="h-1 flex-1 bg-white/10">
        <div className="h-full bg-gold" style={{ width: `${Math.min(100, (v / max) * 100)}%` }} />
      </div>
    </div>
  )
}
