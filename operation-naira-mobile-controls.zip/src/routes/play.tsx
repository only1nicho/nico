import { createFileRoute } from '@tanstack/react-router'
import { GameView } from '@/components/GameView'
import { loadoutFromSearch } from '@/data/game'

interface PlaySearch {
  p?: string
  pl?: string
  pa?: string
  s?: string
  sl?: string
  sa?: string
}

export const Route = createFileRoute('/play')({
  validateSearch: (q: Record<string, unknown>): PlaySearch => {
    const out: PlaySearch = {}
    for (const k of ['p', 'pl', 'pa', 's', 'sl', 'sa'] as const) if (q[k] != null && q[k] !== '') out[k] = String(q[k])
    return out
  },
  head: () => ({ meta: [{ title: 'Oshodi Market · Operation Naira' }] }),
  component: Play,
})

function Play() {
  const search = Route.useSearch()
  return <GameView loadout={loadoutFromSearch(search as Record<string, unknown>)} />
}
