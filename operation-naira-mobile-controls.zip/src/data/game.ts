/**
 * Stubbed game content for Operation Naira.
 *
 * Everything the UI and the training engine read about weapons, attachments,
 * maps and the player profile lives here. A later milestone swaps the profile
 * and ownership data for real persistence; weapon balance stays in code.
 */

export type WeaponClass = 'ar' | 'smg' | 'dmr' | 'sniper' | 'lmg' | 'pistol'
export type Slot = 'primary' | 'secondary'
export type AttachmentSlot = 'optic' | 'muzzle' | 'barrel' | 'magazine' | 'stock'

export interface Weapon {
  id: string
  name: string
  nickname: string
  class: WeaponClass
  slot: Slot
  origin: string
  description: string
  damage: number
  rpm: number
  mag: number
  reserve: number
  /** seconds */
  reload: number
  /** radians of random cone when firing from the hip */
  hipSpread: number
  /** radians of vertical kick per shot */
  recoil: number
  /** metres before damage falloff begins */
  range: number
  auto: boolean
  /** 0-100 */
  mobility: number
  /** base ADS zoom with iron sights / built-in optic */
  zoom: number
  unlockLevel: number
  price: number
  colors: { body: string; furniture: string }
}

export const WEAPONS: Weapon[] = [
  {
    id: 'obj006',
    name: 'OBJ-006',
    nickname: 'Ogun',
    class: 'ar',
    slot: 'primary',
    origin: 'DICON, Kaduna',
    description:
      'Built in Kaduna by the Defence Industries Corporation of Nigeria. Hard-hitting, dependable and named for the Yoruba god of iron.',
    damage: 31,
    rpm: 600,
    mag: 30,
    reserve: 150,
    reload: 2.3,
    hipSpread: 0.045,
    recoil: 0.018,
    range: 45,
    auto: true,
    mobility: 62,
    zoom: 1.3,
    unlockLevel: 1,
    price: 0,
    colors: { body: '#1f2124', furniture: '#7a4524' },
  },
  {
    id: 'tavor',
    name: 'X95 Bullpup',
    nickname: 'Sango',
    class: 'ar',
    slot: 'primary',
    origin: 'Special Forces issue',
    description: 'Compact bullpup that fires like thunder. Fast rate of fire, very manageable kick.',
    damage: 26,
    rpm: 780,
    mag: 30,
    reserve: 150,
    reload: 2.6,
    hipSpread: 0.038,
    recoil: 0.013,
    range: 40,
    auto: true,
    mobility: 70,
    zoom: 1.3,
    unlockLevel: 8,
    price: 85000,
    colors: { body: '#2c2e2a', furniture: '#8a7a55' },
  },
  {
    id: 'mp5',
    name: 'MP5',
    nickname: 'Danfo',
    class: 'smg',
    slot: 'primary',
    origin: 'Police Mobile Force',
    description: 'Weaves through traffic like a Lagos bus driver. Unmatched up close, weak past the bus stop.',
    damage: 21,
    rpm: 900,
    mag: 32,
    reserve: 192,
    reload: 2.0,
    hipSpread: 0.03,
    recoil: 0.01,
    range: 22,
    auto: true,
    mobility: 88,
    zoom: 1.25,
    unlockLevel: 4,
    price: 60000,
    colors: { body: '#1b1c1f', furniture: '#1b1c1f' },
  },
  {
    id: 'fal',
    name: 'FN FAL',
    nickname: 'Harmattan',
    class: 'dmr',
    slot: 'primary',
    origin: 'Nigerian Army classic',
    description: 'A battle rifle that cuts through like the dry season wind. Semi-auto, two-tap lethal.',
    damage: 52,
    rpm: 420,
    mag: 20,
    reserve: 100,
    reload: 2.7,
    hipSpread: 0.06,
    recoil: 0.034,
    range: 70,
    auto: false,
    mobility: 55,
    zoom: 1.4,
    unlockLevel: 12,
    price: 120000,
    colors: { body: '#232427', furniture: '#2e3a2a' },
  },
  {
    id: 'dragunov',
    name: 'SVD',
    nickname: 'Zuma',
    class: 'sniper',
    slot: 'primary',
    origin: 'Marksman school, Jaji',
    description: 'As unshakeable as Zuma Rock. One shot to the head ends any argument.',
    damage: 96,
    rpm: 70,
    mag: 10,
    reserve: 40,
    reload: 3.0,
    hipSpread: 0.12,
    recoil: 0.07,
    range: 120,
    auto: false,
    mobility: 45,
    zoom: 5,
    unlockLevel: 18,
    price: 210000,
    colors: { body: '#1e1f22', furniture: '#6b3b1e' },
  },
  {
    id: 'pkm',
    name: 'PKM',
    nickname: 'Area Father',
    class: 'lmg',
    slot: 'primary',
    origin: 'Captured militia stock',
    description: 'Nobody argues with Area Father. A hundred-round belt and a slow, heavy swing.',
    damage: 33,
    rpm: 650,
    mag: 100,
    reserve: 200,
    reload: 5.2,
    hipSpread: 0.07,
    recoil: 0.02,
    range: 55,
    auto: true,
    mobility: 35,
    zoom: 1.3,
    unlockLevel: 22,
    price: 260000,
    colors: { body: '#1d1e20', furniture: '#5a3420' },
  },
  {
    id: 'eko9',
    name: 'Eko 9mm',
    nickname: 'Eko',
    class: 'pistol',
    slot: 'secondary',
    origin: 'Standard sidearm',
    description: 'Reliable 9mm sidearm. Quick to draw when your primary runs dry in the middle of a go-slow.',
    damage: 28,
    rpm: 450,
    mag: 15,
    reserve: 60,
    reload: 1.5,
    hipSpread: 0.025,
    recoil: 0.025,
    range: 20,
    auto: false,
    mobility: 95,
    zoom: 1.15,
    unlockLevel: 1,
    price: 0,
    colors: { body: '#1a1b1e', furniture: '#1a1b1e' },
  },
  {
    id: 'oga50',
    name: 'Desert .50',
    nickname: 'Oga',
    class: 'pistol',
    slot: 'secondary',
    origin: 'Big man special',
    description: 'For the oga at the top. Seven rounds of hand cannon that lands with authority.',
    damage: 62,
    rpm: 200,
    mag: 7,
    reserve: 35,
    reload: 2.0,
    hipSpread: 0.04,
    recoil: 0.06,
    range: 28,
    auto: false,
    mobility: 85,
    zoom: 1.2,
    unlockLevel: 10,
    price: 75000,
    colors: { body: '#b5b2a8', furniture: '#1a1b1e' },
  },
]

type StatMods = Partial<Record<'damage' | 'rpm' | 'mag' | 'reload' | 'hipSpread' | 'recoil' | 'range' | 'mobility', number>>

export interface Attachment {
  id: string
  slot: AttachmentSlot
  name: string
  description: string
  /** multipliers applied to the weapon's base stats */
  mods: StatMods
  zoom?: number
  price: number
}

export const ATTACHMENTS: Attachment[] = [
  { id: 'reflex', slot: 'optic', name: 'Eko Reflex', description: 'Clean red dot, fast target pickup.', mods: { mobility: 0.98 }, zoom: 1.45, price: 12000 },
  { id: 'holo', slot: 'optic', name: 'Holographic', description: 'Wide window, ring reticle.', mods: { recoil: 0.97, mobility: 0.97 }, zoom: 1.6, price: 18000 },
  { id: 'acog', slot: 'optic', name: 'Zuma 3x', description: 'Mid-range magnified optic.', mods: { mobility: 0.93, range: 1.1 }, zoom: 2.6, price: 26000 },
  { id: 'suppressor', slot: 'muzzle', name: 'Night Market Suppressor', description: 'Hides you from the minimap. Slight range loss.', mods: { range: 0.9, recoil: 0.95 }, price: 22000 },
  { id: 'compensator', slot: 'muzzle', name: 'Compensator', description: 'Tames vertical kick.', mods: { recoil: 0.8, hipSpread: 1.05 }, price: 15000 },
  { id: 'longbarrel', slot: 'barrel', name: 'Long Barrel', description: 'More reach, slower handling.', mods: { range: 1.3, damage: 1.05, mobility: 0.92 }, price: 20000 },
  { id: 'shortbarrel', slot: 'barrel', name: 'Short Barrel', description: 'Snappy and mobile.', mods: { range: 0.8, mobility: 1.08, hipSpread: 0.85 }, price: 14000 },
  { id: 'extmag', slot: 'magazine', name: 'Extended Mag', description: 'Fifty percent more rounds.', mods: { mag: 1.5, reload: 1.15, mobility: 0.96 }, price: 16000 },
  { id: 'fastmag', slot: 'magazine', name: 'Fast Mag', description: 'Taped mags, lightning reloads.', mods: { reload: 0.7 }, price: 13000 },
  { id: 'heavystock', slot: 'stock', name: 'Heavy Stock', description: 'Rock-steady, heavier to carry.', mods: { recoil: 0.82, mobility: 0.93 }, price: 15000 },
  { id: 'nostock', slot: 'stock', name: 'No Stock', description: 'Strip it down for speed.', mods: { recoil: 1.25, mobility: 1.12 }, price: 8000 },
]

export const ATTACHMENT_SLOTS: AttachmentSlot[] = ['optic', 'muzzle', 'barrel', 'magazine', 'stock']

export function slotsFor(cls: WeaponClass): AttachmentSlot[] {
  if (cls === 'pistol') return ['optic', 'muzzle', 'magazine']
  if (cls === 'sniper') return ['muzzle', 'barrel', 'magazine', 'stock']
  return ATTACHMENT_SLOTS
}

export const MAX_LEVEL = 5

export function upgradeCost(level: number): number {
  return [0, 25000, 45000, 70000, 110000][level] ?? 0
}

export interface WeaponStats extends Weapon {
  level: number
  attachments: string[]
  suppressed: boolean
  optic: string | null
}

export function getWeapon(id: string): Weapon {
  return WEAPONS.find((w) => w.id === id) ?? WEAPONS[0]
}

export function getAttachment(id: string): Attachment | undefined {
  return ATTACHMENTS.find((a) => a.id === id)
}

/** Final weapon stats after level upgrades and attachments. Shared by the Armory and the engine. */
export function computeStats(weaponId: string, level = 1, attachmentIds: string[] = []): WeaponStats {
  const base = getWeapon(weaponId)
  const lvl = Math.max(1, Math.min(MAX_LEVEL, level)) - 1
  const s: WeaponStats = {
    ...base,
    level: lvl + 1,
    attachments: [],
    suppressed: false,
    optic: null,
    damage: base.damage * (1 + 0.03 * lvl),
    recoil: base.recoil * (1 - 0.05 * lvl),
    hipSpread: base.hipSpread * (1 - 0.03 * lvl),
    reload: base.reload * (1 - 0.03 * lvl),
    range: base.range * (1 + 0.04 * lvl),
  }
  const allowed = slotsFor(base.class)
  const used = new Set<AttachmentSlot>()
  for (const id of attachmentIds) {
    const a = getAttachment(id)
    if (!a || !allowed.includes(a.slot) || used.has(a.slot)) continue
    used.add(a.slot)
    s.attachments.push(a.id)
    for (const [k, v] of Object.entries(a.mods) as [keyof StatMods, number][]) s[k] = s[k] * v
    if (a.zoom) {
      s.zoom = a.zoom
      s.optic = a.id
    }
    if (a.id === 'suppressor') s.suppressed = true
  }
  s.mag = Math.round(s.mag)
  s.mobility = Math.min(100, s.mobility)
  s.damage = Math.round(s.damage * 10) / 10
  return s
}

/** Normalised 0-100 values for stat bars. */
export function statBars(s: WeaponStats) {
  const clamp = (v: number) => Math.max(4, Math.min(100, Math.round(v)))
  return {
    damage: clamp((s.damage / 100) * 100),
    fireRate: clamp((s.rpm / 950) * 100),
    accuracy: clamp(100 - s.hipSpread * 900),
    control: clamp(100 - s.recoil * 1300),
    range: clamp((s.range / 120) * 100),
    mobility: clamp(s.mobility),
  }
}

export interface Loadout {
  primary: { id: string; level: number; attachments: string[] }
  secondary: { id: string; level: number; attachments: string[] }
}

export const DEFAULT_LOADOUT: Loadout = {
  primary: { id: 'obj006', level: 1, attachments: [] },
  secondary: { id: 'eko9', level: 1, attachments: [] },
}

/** Loadouts travel from the Armory to the training ground as URL search params. */
export function loadoutToSearch(l: Loadout): Record<string, string> {
  return {
    p: l.primary.id,
    pl: String(l.primary.level),
    pa: l.primary.attachments.join(','),
    s: l.secondary.id,
    sl: String(l.secondary.level),
    sa: l.secondary.attachments.join(','),
  }
}

export function loadoutFromSearch(q: Record<string, unknown>): Loadout {
  const str = (v: unknown, d: string) => (typeof v === 'string' && v.length ? v : typeof v === 'number' ? String(v) : d)
  const list = (v: unknown) => str(v, '').split(',').filter(Boolean)
  return {
    primary: { id: str(q.p, 'obj006'), level: Number(str(q.pl, '1')) || 1, attachments: list(q.pa) },
    secondary: { id: str(q.s, 'eko9'), level: Number(str(q.sl, '1')) || 1, attachments: list(q.sa) },
  }
}

export interface GameMap {
  id: string
  name: string
  city: string
  image: string
  blurb: string
  modes: string[]
  status: 'playable' | 'online-soon'
}

export const MAPS: GameMap[] = [
  {
    id: 'oshodi',
    name: 'Oshodi Market',
    city: 'Lagos',
    image: '/img/map-oshodi',
    blurb: 'Zinc-roof stalls, a go-slow of abandoned danfos and an overhead footbridge. Close quarters, no mercy.',
    modes: ['Training', 'Team Deathmatch', 'Domination'],
    status: 'playable',
  },
  {
    id: 'bridge',
    name: 'Third Mainland',
    city: 'Lagos',
    image: '/img/map-bridge',
    blurb: 'Eleven kilometres of bridge, a burning tanker and the lagoon below. Long sightlines, nowhere to hide.',
    modes: ['Search & Destroy', 'Hardpoint'],
    status: 'online-soon',
  },
  {
    id: 'abuja',
    name: 'Central District',
    city: 'Abuja',
    image: '/img/map-abuja',
    blurb: 'Government blocks under Aso Rock, choked with harmattan dust. Hold the capital at all costs.',
    modes: ['Domination', 'Battle Royale'],
    status: 'online-soon',
  },
]

export const PROFILE = {
  callsign: 'EkoSniper',
  level: 27,
  xp: 6420,
  xpNext: 9000,
  naira: 482500,
  rank: 'Staff Sergeant',
  ownedWeapons: ['obj006', 'mp5', 'tavor', 'fal', 'dragunov', 'pkm', 'eko9', 'oga50'],
  squad: [
    { name: 'Chioma_Fire', status: 'In lobby', level: 31 },
    { name: 'AbuWarlord', status: 'In match · Oshodi', level: 24 },
    { name: 'Lagbaja99', status: 'Online', level: 12 },
  ],
}

/** Fictional opponents for the AI training mode. */
export const BOT_NAMES = [
  'Baba Ijebu',
  'Agbero Kola',
  'Sunny Danger',
  'Emeka Gbese',
  'Musa Dogo',
  'Ibro Wahala',
  'Chuks Ringo',
  'Yinka Lagbaja',
  'Tunde Scatter',
  'Bayo Kasala',
]

export const STREAK_CALLOUTS: Record<number, string> = {
  2: 'DOUBLE KILL · E DON CASE!',
  3: 'TRIPLE KILL · NA WA O!',
  5: 'RAMPAGE · YOU BE ODOGWU!',
  8: 'UNSTOPPABLE · OGA AT THE TOP!',
}

export const MATCH_SECONDS = 300
export const MATCH_KILL_TARGET = 30
