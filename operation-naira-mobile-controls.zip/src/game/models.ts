import * as THREE from 'three'
import type { Weapon } from '@/data/game'

const metal = (color = '#1f2124') => new THREE.MeshStandardMaterial({ color, metalness: 0.75, roughness: 0.42 })
const polymer = (color: string) => new THREE.MeshStandardMaterial({ color, metalness: 0.1, roughness: 0.7 })

function box(w: number, h: number, d: number, mat: THREE.Material, x = 0, y = 0, z = 0, rx = 0) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat)
  m.position.set(x, y, z)
  m.rotation.x = rx
  m.castShadow = true
  return m
}

function cyl(r: number, len: number, mat: THREE.Material, x = 0, y = 0, z = 0, seg = 14) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, seg), mat)
  m.rotation.x = Math.PI / 2
  m.position.set(x, y, z)
  m.castShadow = true
  return m
}

interface Proportions {
  rec: number
  recH: number
  barrel: number
  guard: number
  stock: number
  magH: number
  magRot: number
  magW: number
  boxMag?: boolean
}

const PROPS: Record<Exclude<Weapon['class'], 'pistol'>, Proportions> = {
  ar: { rec: 0.4, recH: 0.085, barrel: 0.3, guard: 0.22, stock: 0.26, magH: 0.17, magRot: 0.28, magW: 0.07 },
  smg: { rec: 0.3, recH: 0.08, barrel: 0.12, guard: 0.15, stock: 0.18, magH: 0.15, magRot: 0.12, magW: 0.05 },
  dmr: { rec: 0.44, recH: 0.09, barrel: 0.42, guard: 0.26, stock: 0.28, magH: 0.12, magRot: 0.05, magW: 0.07 },
  sniper: { rec: 0.44, recH: 0.08, barrel: 0.55, guard: 0.28, stock: 0.3, magH: 0.1, magRot: 0.05, magW: 0.07 },
  lmg: { rec: 0.48, recH: 0.11, barrel: 0.42, guard: 0.18, stock: 0.28, magH: 0.12, magRot: 0, magW: 0.11, boxMag: true },
}

export interface WeaponModel {
  group: THREE.Group
  muzzle: THREE.Object3D
  /** height of the sight line above the model origin, used to align ADS */
  sightY: number
  /** distance from origin to sight's rear, used to set ADS eye relief */
  length: number
}

/**
 * Builds a stylised but proportioned weapon from primitives, pointing down -Z.
 * Attachments are rendered so the Armory preview and the in-game viewmodel match.
 */
export function buildWeaponModel(w: Weapon, attachments: string[]): WeaponModel {
  const g = new THREE.Group()
  const body = metal(w.colors.body)
  const furn = w.colors.furniture === w.colors.body ? metal(w.colors.body) : polymer(w.colors.furniture)
  const dark = metal('#121314')
  const has = (id: string) => attachments.includes(id)
  const muzzle = new THREE.Object3D()

  if (w.class === 'pistol') {
    const big = w.id === 'oga50'
    const s = big ? 1.25 : 1
    g.add(box(0.032 * s, 0.038 * s, 0.2 * s, body, 0, 0.03 * s, -0.05 * s))
    g.add(box(0.03 * s, 0.03 * s, 0.17 * s, dark, 0, 0.0, -0.04 * s))
    g.add(box(0.03 * s, 0.11 * s, 0.045 * s, furn, 0, -0.055 * s, 0.025 * s, -0.25))
    g.add(box(0.008, 0.012, 0.01, dark, 0, 0.055 * s, -0.14 * s))
    let tip = -0.15 * s
    if (has('suppressor')) {
      g.add(cyl(0.018, 0.14, dark, 0, 0.03 * s, tip - 0.07))
      tip -= 0.14
    } else if (has('compensator')) {
      g.add(box(0.034 * s, 0.04 * s, 0.035, dark, 0, 0.03 * s, tip - 0.015))
      tip -= 0.035
    }
    if (has('extmag')) g.add(box(0.026 * s, 0.07, 0.035 * s, dark, 0, -0.14 * s, 0.035 * s, -0.25))
    let sightY = 0.06 * s
    if (has('reflex') || has('holo') || has('acog')) {
      g.add(box(0.03, 0.03, 0.04, dark, 0, 0.065 * s, -0.02))
      g.add(box(0.03, 0.002, 0.002, polymer('#ff3030'), 0, 0.085 * s, -0.04))
      sightY = 0.08 * s
    }
    muzzle.position.set(0, 0.03 * s, tip)
    g.add(muzzle)
    return { group: g, muzzle, sightY, length: 0.25 }
  }

  const p = PROPS[w.class]
  const barrelLen = p.barrel * (has('longbarrel') ? 1.35 : has('shortbarrel') ? 0.7 : 1)
  const recZ = -p.rec / 2 + 0.08
  // receiver + top rail
  g.add(box(0.065, p.recH, p.rec, body, 0, 0, recZ))
  g.add(box(0.03, 0.012, p.rec * 0.8, dark, 0, p.recH / 2 + 0.006, recZ))
  // handguard
  const guardZ = recZ - p.rec / 2 - p.guard / 2 + 0.02
  g.add(box(0.06, p.recH * 0.8, p.guard, furn, 0, -0.005, guardZ))
  // barrel
  const barrelStart = guardZ - p.guard / 2
  g.add(cyl(0.012, barrelLen + 0.04, dark, 0, 0.012, barrelStart - barrelLen / 2 + 0.02))
  let tip = barrelStart - barrelLen
  if (w.class === 'ar' && w.id === 'obj006') {
    // AK gas tube
    g.add(cyl(0.01, p.guard + 0.08, body, 0, 0.035, guardZ - 0.03))
  }
  if (has('suppressor')) {
    g.add(cyl(0.024, 0.2, dark, 0, 0.012, tip - 0.1, 18))
    tip -= 0.2
  } else if (has('compensator')) {
    g.add(cyl(0.02, 0.06, dark, 0, 0.012, tip - 0.03, 8))
    tip -= 0.06
  } else {
    g.add(cyl(0.017, 0.04, dark, 0, 0.012, tip - 0.02, 8))
    tip -= 0.04
  }
  muzzle.position.set(0, 0.012, tip)
  g.add(muzzle)

  // magazine
  const magH = p.magH * (has('extmag') ? 1.45 : 1)
  if (p.boxMag) {
    g.add(box(0.1, 0.11 * (has('extmag') ? 1.3 : 1), 0.12, polymer('#3b4a2c'), 0.06, -0.08, recZ - 0.02))
  } else {
    const mag = box(0.035, magH, p.magW, w.id === 'obj006' ? polymer('#5a3018') : dark, 0, -p.recH / 2 - magH / 2 + 0.02, recZ - 0.02, p.magRot)
    g.add(mag)
    if (has('fastmag')) g.add(box(0.036, magH, p.magW, polymer('#2a2a2a'), 0.04, -p.recH / 2 - magH / 2 + 0.02, recZ - 0.02, p.magRot))
  }
  // pistol grip
  g.add(box(0.035, 0.1, 0.045, furn, 0, -0.085, recZ + p.rec / 2 - 0.08, -0.32))
  // stock
  if (!has('nostock')) {
    const heavy = has('heavystock')
    g.add(box(heavy ? 0.055 : 0.045, heavy ? 0.1 : 0.075, p.stock, furn, 0, -0.015, recZ + p.rec / 2 + p.stock / 2))
    g.add(box(0.05, 0.11, 0.02, dark, 0, -0.025, recZ + p.rec / 2 + p.stock))
  }
  if (w.class === 'lmg') {
    // bipod folded under barrel
    g.add(box(0.012, 0.012, 0.2, dark, 0.015, -0.03, barrelStart - 0.1))
    g.add(box(0.012, 0.012, 0.2, dark, -0.015, -0.03, barrelStart - 0.1))
  }

  // optics
  const top = p.recH / 2 + 0.012
  let sightY = top + 0.03
  let optic: string | null = attachments.find((a) => ['reflex', 'holo', 'acog'].includes(a)) ?? null
  if (w.class === 'sniper') optic = 'scope'
  if (!optic) {
    g.add(box(0.008, 0.035, 0.01, dark, 0, top + 0.012, tip + 0.06))
    g.add(box(0.03, 0.025, 0.012, dark, 0, top + 0.01, recZ + p.rec / 2 - 0.05))
  } else if (optic === 'reflex') {
    g.add(box(0.035, 0.02, 0.05, dark, 0, top + 0.01, recZ - 0.02))
    g.add(box(0.034, 0.04, 0.006, dark, 0, top + 0.035, recZ - 0.04))
    sightY = top + 0.04
  } else if (optic === 'holo') {
    g.add(box(0.045, 0.025, 0.08, dark, 0, top + 0.012, recZ - 0.02))
    g.add(box(0.045, 0.045, 0.008, dark, 0, top + 0.045, recZ - 0.06))
    g.add(box(0.045, 0.045, 0.008, dark, 0, top + 0.045, recZ + 0.02))
    g.add(box(0.008, 0.045, 0.08, dark, 0.02, top + 0.045, recZ - 0.02))
    sightY = top + 0.045
  } else {
    const len = optic === 'scope' ? 0.32 : 0.15
    const r = optic === 'scope' ? 0.026 : 0.022
    g.add(cyl(r, len, dark, 0, top + 0.045, recZ - 0.02, 18))
    g.add(cyl(r * 1.35, 0.04, dark, 0, top + 0.045, recZ - 0.02 - len / 2))
    g.add(cyl(r * 1.2, 0.03, dark, 0, top + 0.045, recZ - 0.02 + len / 2))
    g.add(box(0.02, 0.03, 0.03, dark, 0, top + 0.015, recZ - 0.06))
    g.add(box(0.02, 0.03, 0.03, dark, 0, top + 0.015, recZ + 0.04))
    sightY = top + 0.045
  }
  return { group: g, muzzle, sightY, length: p.rec + p.stock }
}

export interface SoldierModel {
  group: THREE.Group
  parts: THREE.Mesh[]
  gun: THREE.Object3D
  legs: [THREE.Object3D, THREE.Object3D]
  arms: THREE.Object3D
}

/** Low-poly militia fighter with named hitboxes for damage multipliers. */
export function buildSoldier(camo: THREE.Texture, accent: string): SoldierModel {
  const g = new THREE.Group()
  const uni = new THREE.MeshStandardMaterial({ map: camo, roughness: 0.9 })
  const vest = new THREE.MeshStandardMaterial({ color: '#2b2f26', roughness: 0.85 })
  const skin = new THREE.MeshStandardMaterial({ color: '#4a2c1c', roughness: 0.6 })
  const band = new THREE.MeshStandardMaterial({ color: accent, roughness: 0.7 })
  const boots = new THREE.MeshStandardMaterial({ color: '#141414', roughness: 0.8 })
  const parts: THREE.Mesh[] = []
  const part = (m: THREE.Mesh, name: 'head' | 'body' | 'legs') => {
    m.userData.part = name
    m.castShadow = true
    parts.push(m)
    return m
  }

  const mkLeg = (x: number) => {
    const pivot = new THREE.Group()
    pivot.position.set(x, 0.92, 0)
    const leg = part(new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.88, 0.2), uni), 'legs')
    leg.position.y = -0.44
    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.12, 0.28), boots)
    boot.position.set(0, -0.86, -0.04)
    pivot.add(leg, boot)
    g.add(pivot)
    return pivot
  }
  const legs: [THREE.Object3D, THREE.Object3D] = [mkLeg(-0.11), mkLeg(0.11)]

  const torso = part(new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.6, 0.26), uni), 'body')
  torso.position.y = 1.22
  const vestM = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.42, 0.3), vest)
  vestM.position.y = 1.26
  const neck = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 0.12), skin)
  neck.position.y = 1.56
  const head = part(new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.26, 0.24), skin), 'head')
  head.position.y = 1.72
  const bandana = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.08, 0.26), band)
  bandana.position.y = 1.8
  const armband = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.07, 0.17), band)
  armband.position.set(-0.29, 1.36, 0)
  g.add(torso, vestM, neck, head, bandana, armband)

  // arms holding a rifle at the ready
  const arms = new THREE.Group()
  arms.position.set(0, 1.38, 0)
  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.5), uni)
  armL.position.set(-0.2, -0.06, -0.2)
  const armR = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.44), uni)
  armR.position.set(0.2, -0.04, -0.12)
  const gun = new THREE.Group()
  const gunBody = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.1, 0.8), new THREE.MeshStandardMaterial({ color: '#1c1c1c', metalness: 0.6, roughness: 0.5 }))
  gunBody.castShadow = true
  const gunMag = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.16, 0.08), new THREE.MeshStandardMaterial({ color: '#5a3018' }))
  gunMag.position.set(0, -0.11, -0.05)
  gunMag.rotation.x = 0.3
  gun.add(gunBody, gunMag)
  gun.position.set(0.05, 0, -0.42)
  const gunTip = new THREE.Object3D()
  gunTip.position.set(0, 0, -0.42)
  gun.add(gunTip)
  gun.userData.tip = gunTip
  arms.add(armL, armR, gun)
  g.add(arms)

  return { group: g, parts, gun, legs, arms }
}

/** First-person arms in the uniform of the Nigerian forces. */
export function buildArms(camo: THREE.Texture) {
  const g = new THREE.Group()
  const sleeve = new THREE.MeshStandardMaterial({ map: camo, roughness: 0.9 })
  const glove = new THREE.MeshStandardMaterial({ color: '#1e1e1c', roughness: 0.8 })
  const r = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.075, 0.36), sleeve)
  r.position.set(0.07, -0.12, 0.2)
  r.rotation.set(0.35, 0.25, 0)
  const rg = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.07, 0.09), glove)
  rg.position.set(0.02, -0.07, 0.04)
  const l = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.075, 0.42), sleeve)
  l.position.set(-0.11, -0.12, -0.08)
  l.rotation.set(0.2, -0.45, 0)
  const lg = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.06, 0.09), glove)
  lg.position.set(-0.02, -0.05, -0.22)
  g.add(r, rg, l, lg)
  return g
}
