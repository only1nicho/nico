import * as THREE from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import {
  asphaltTexture,
  concreteTexture,
  containerTexture,
  corrugatedTexture,
  danfoTexture,
  glowTexture,
  lateriteTexture,
  rng,
  sandbagTexture,
  signTexture,
  wallTexture,
} from './textures'

export interface World {
  group: THREE.Group
  colliders: THREE.Box3[]
  nav: THREE.Vector3[]
  bounds: number
  sunDir: THREE.Vector3
  update(dt: number, t: number): void
}

const BOUNDS = 58

/** Box geometry whose UVs are scaled to world metres so tiled textures stay a constant size. */
function tiledBox(w: number, h: number, d: number, tile: number) {
  const g = new THREE.BoxGeometry(w, h, d)
  const uv = g.attributes.uv as THREE.BufferAttribute
  const dims = [
    [d, h],
    [d, h],
    [w, d],
    [w, d],
    [w, h],
    [w, h],
  ]
  for (let f = 0; f < 6; f++)
    for (let i = 0; i < 4; i++) {
      const k = f * 4 + i
      uv.setXY(k, (uv.getX(k) * dims[f][0]) / tile, (uv.getY(k) * dims[f][1]) / tile)
    }
  return g
}

/**
 * Collects static geometry per material and merges it into a handful of draw calls.
 * Supports a transform stack so composite props (buses, stalls) can be placed and rotated.
 */
class Builder {
  private batches = new Map<string, { mat: THREE.Material; geos: THREE.BufferGeometry[] }>()
  private stack: THREE.Matrix4[] = [new THREE.Matrix4()]
  private rotStack: number[] = [0]
  colliders: THREE.Box3[] = []

  push(x: number, z: number, ry = 0) {
    const m = new THREE.Matrix4().makeRotationY(ry).setPosition(x, 0, z)
    this.stack.push(this.top.clone().multiply(m))
    this.rotStack.push(this.rotStack[this.rotStack.length - 1] + ry)
  }
  pop() {
    this.stack.pop()
    this.rotStack.pop()
  }
  private get top() {
    return this.stack[this.stack.length - 1]
  }

  add(key: string, mat: THREE.Material, geo: THREE.BufferGeometry, x: number, y: number, z: number, rx = 0, ry = 0, rz = 0) {
    const local = new THREE.Matrix4().compose(
      new THREE.Vector3(x, y, z),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz)),
      new THREE.Vector3(1, 1, 1),
    )
    geo.applyMatrix4(this.top.clone().multiply(local))
    if (!this.batches.has(key)) this.batches.set(key, { mat, geos: [] })
    this.batches.get(key)!.geos.push(geo)
  }

  /** Axis-aligned collider in the current local frame (rotations must be multiples of 90°). */
  collide(cx: number, cz: number, w: number, d: number, y0: number, y1: number) {
    const corners = [
      new THREE.Vector3(cx - w / 2, y0, cz - d / 2),
      new THREE.Vector3(cx + w / 2, y1, cz + d / 2),
    ].map((v) => v.applyMatrix4(this.top))
    const b = new THREE.Box3().setFromPoints(corners)
    this.colliders.push(b)
  }

  /** Solid box sitting on y0, rendered and collidable. */
  solid(key: string, mat: THREE.Material, w: number, h: number, d: number, x: number, y0: number, z: number, tile = 0) {
    const geo = tile ? tiledBox(w, h, d, tile) : new THREE.BoxGeometry(w, h, d)
    this.add(key, mat, geo, x, y0 + h / 2, z)
    this.collide(x, z, w, d, y0, y0 + h)
  }

  build(group: THREE.Group) {
    for (const { mat, geos } of this.batches.values()) {
      const merged = mergeGeometries(geos, false)
      if (!merged) continue
      const mesh = new THREE.Mesh(merged, mat)
      mesh.castShadow = true
      mesh.receiveShadow = true
      group.add(mesh)
      geos.forEach((g) => g.dispose())
    }
  }
}

const std = (o: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial({ roughness: 0.85, ...o })

export function buildOshodi(): World {
  const group = new THREE.Group()
  const b = new Builder()
  const r = rng(2024)

  // ---------- materials ----------
  const lat = lateriteTexture()
  lat.repeat.set(30, 30)
  const asphalt = asphaltTexture()
  const concrete = concreteTexture()
  const M = {
    concrete: std({ map: concrete }),
    asphalt: std({ map: asphalt, roughness: 0.95 }),
    white: std({ color: '#d9d4c5' }),
    yellowLine: std({ color: '#d6a618' }),
    walls: ['#d8c9a6', '#9fb7c4', '#d6a7a0', '#c79b54', '#a9b48a', '#e2ddd0'].map((c, i) => std({ map: wallTexture(c, 40 + i) })),
    zinc: [corrugatedTexture('#8a8f92', 1), corrugatedTexture('#9a5a32', 2), corrugatedTexture('#2f5fa8', 3), corrugatedTexture('#a8342c', 4), corrugatedTexture('#3e7a46', 5)].map(
      (t) => std({ map: t, metalness: 0.4, roughness: 0.6, side: THREE.DoubleSide }),
    ),
    wood: std({ color: '#6b4a2f' }),
    darkWood: std({ color: '#3d2a1c' }),
    pole: std({ color: '#5a4a3a' }),
    metal: std({ color: '#3a3c3e', metalness: 0.6, roughness: 0.5 }),
    tank: std({ color: '#151515', roughness: 0.6 }),
    yellow: std({ color: '#e1b20e', roughness: 0.55, metalness: 0.2 }),
    glass: std({ color: '#1a2026', roughness: 0.2, metalness: 0.5 }),
    tyre: std({ color: '#111', roughness: 0.95 }),
    burnt: std({ color: '#231d19', roughness: 1 }),
    sandbag: std({ map: sandbagTexture() }),
    containers: [containerTexture('#8c2f22', 9), containerTexture('#2e4f79', 10), containerTexture('#3b6a3a', 11), containerTexture('#b07a1e', 12)].map((t) => std({ map: t, metalness: 0.3 })),
    barrelBlue: std({ color: '#1f4fa0', roughness: 0.5 }),
    barrelRust: std({ color: '#7a3a1a', roughness: 0.8 }),
    goods: ['#d63a2a', '#e8a21a', '#3a9a3a', '#e8e0c8', '#7a2a8a', '#1a7ad0'].map((c) => std({ color: c })),
    skyline: std({ color: '#3a2f33', roughness: 1 }),
    danfo: [0, 1, 2, 3, 4, 5].map((i) => std({ map: danfoTexture(i), roughness: 0.6 })),
  }

  // ---------- ground ----------
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), std({ map: lat }))
  ground.rotation.x = -Math.PI / 2
  ground.receiveShadow = true
  group.add(ground)

  const road = (x: number, z: number, w: number, d: number) => {
    const g = new THREE.PlaneGeometry(w, d)
    const uv = g.attributes.uv as THREE.BufferAttribute
    for (let i = 0; i < uv.count; i++) uv.setXY(i, (uv.getX(i) * w) / 8, (uv.getY(i) * d) / 8)
    b.add('asphalt', M.asphalt, g, x, 0.02, z, -Math.PI / 2)
  }
  road(0, 0, 14, 150)
  road(0, 32, 150, 10)
  for (let z = -56; z < 58; z += 6) b.add('white', M.white, new THREE.PlaneGeometry(0.2, 3), 0, 0.03, z, -Math.PI / 2)
  for (let x = -56; x < 58; x += 6) if (Math.abs(x) > 8) b.add('white', M.white, new THREE.PlaneGeometry(3, 0.2), x, 0.03, 32, -Math.PI / 2)
  b.add('yellowLine', M.yellowLine, new THREE.PlaneGeometry(0.25, 150), -6.6, 0.03, 0, -Math.PI / 2)
  b.add('yellowLine', M.yellowLine, new THREE.PlaneGeometry(0.25, 150), 6.6, 0.03, 0, -Math.PI / 2)

  // ---------- perimeter buildings ----------
  const signs = [
    signTexture('MAMA CHI PURE WATER', 'COLD WATER DEY · 08031234567', '#f4f1e8', '#1a5aa8'),
    signTexture("GOD'S TIME", 'PHONE & LAPTOP REPAIRS', '#ffd21f', '#b11'),
    signTexture('JOLLOF JUNCTION', 'MAMA PUT · RICE & SWALLOW', '#0a7a3a', '#fff'),
    signTexture('NEPA NO DEY?', 'BUY GEN · ALHAJI & SONS', '#c4161c', '#fff'),
    signTexture('OSHODI', 'WELCOME TO LAGOS · EKO O NI BAJE', '#008751', '#fff'),
    signTexture('EZE MOTORS', 'TOKUNBO CARS · SPARE PARTS', '#111', '#f2c200'),
  ].map((t) => new THREE.MeshStandardMaterial({ map: t, roughness: 0.7 }))
  let signIdx = 0
  const tanks: [number, number, number][] = []

  const perimeter = (side: 0 | 1 | 2 | 3) => {
    for (let s = -74; s < 74; ) {
      const w = 8 + r() * 7
      const h = 7 + Math.floor(r() * 4) * 3.2
      const d = 10
      const along = s + w / 2
      const inward = BOUNDS + 2 + d / 2
      const [x, z, bw, bd] = side === 0 ? [along, -inward, w, d] : side === 1 ? [along, inward, w, d] : side === 2 ? [-inward, along, d, w] : [inward, along, d, w]
      const mat = M.walls[Math.floor(r() * M.walls.length)]
      b.solid(`wall${M.walls.indexOf(mat)}`, mat, bw, h, bd, x, 0, z, 3.2)
      b.add('concrete', M.concrete, new THREE.BoxGeometry(bw + 0.4, 0.3, bd + 0.4), x, h + 0.15, z)
      if (r() > 0.35) tanks.push([x + (r() - 0.5) * bw * 0.6, h + 0.3, z + (r() - 0.5) * bd * 0.6])
      if (r() > 0.55 && signIdx < 24) {
        const mat = signs[signIdx++ % signs.length]
        const sign = new THREE.Mesh(new THREE.PlaneGeometry(6, 2.25), mat)
        const off = inward - d / 2 - 0.05
        const ys = 4 + r() * 2
        if (side === 0) sign.position.set(x, ys, -off)
        if (side === 1) sign.position.set(x, ys, off), (sign.rotation.y = Math.PI)
        if (side === 2) sign.position.set(-off, ys, z), (sign.rotation.y = Math.PI / 2)
        if (side === 3) sign.position.set(off, ys, z), (sign.rotation.y = -Math.PI / 2)
        group.add(sign)
      }
      s += w
    }
  }
  ;([0, 1, 2, 3] as const).forEach(perimeter)
  for (const [x, y, z] of tanks) {
    b.add('tank', M.tank, new THREE.CylinderGeometry(0.75, 0.75, 1.4, 14), x, y + 1.6, z)
    b.add('metal', M.metal, new THREE.BoxGeometry(1.4, 0.9, 1.4), x, y + 0.45, z)
  }

  // distant skyline silhouettes
  for (let i = 0; i < 70; i++) {
    const a = (i / 70) * Math.PI * 2 + r() * 0.05
    const dist = 110 + r() * 90
    const h = 15 + r() * (r() > 0.85 ? 90 : 35)
    const w = 10 + r() * 16
    b.add('skyline', M.skyline, new THREE.BoxGeometry(w, h, w), Math.cos(a) * dist, h / 2, Math.sin(a) * dist)
  }

  // ---------- danfo bus ----------
  const danfo = (x: number, z: number, ry: number, variant: number, burnt = false) => {
    b.push(x, z, ry)
    const body = burnt ? M.burnt : M.yellow
    const side = burnt ? M.burnt : M.danfo[variant % M.danfo.length]
    const key = burnt ? 'burnt' : 'yellow'
    b.add(key, body, new THREE.BoxGeometry(4.6, 1.9, 1.9), 0, 1.3, 0)
    b.add(burnt ? 'burnt' : `danfo${variant % 6}`, side, new THREE.PlaneGeometry(4.6, 1.9), 0, 1.3, 0.96)
    b.add(burnt ? 'burnt' : `danfo${variant % 6}`, side, new THREE.PlaneGeometry(4.6, 1.9), 0, 1.3, -0.96, 0, Math.PI)
    b.add('glass', M.glass, new THREE.PlaneGeometry(1.7, 0.8), -2.31, 1.75, 0, 0, -Math.PI / 2)
    b.add('glass', M.glass, new THREE.PlaneGeometry(1.7, 0.7), 2.31, 1.75, 0, 0, Math.PI / 2)
    b.add('metal', M.metal, new THREE.BoxGeometry(3.6, 0.08, 1.6), 0, 2.32, 0)
    for (const [wx, wz] of [
      [-1.5, 0.85],
      [1.5, 0.85],
      [-1.5, -0.85],
      [1.5, -0.85],
    ])
      b.add('tyre', M.tyre, new THREE.CylinderGeometry(0.36, 0.36, 0.26, 12), wx, 0.36, wz, Math.PI / 2)
    b.collide(0, 0, 4.6, 1.9, 0, 2.3)
    b.pop()
  }

  // go-slow on the main road
  const traffic: [number, number, number][] = [
    [-3.4, -44, 0],
    [3.2, -36, 1],
    [-3.1, -22, 2],
    [3.5, 2, 3],
    [-3.3, 10, 4],
    [3.0, 20, 5],
    [-3.6, 44, 1],
    [3.4, 50, 2],
  ]
  traffic.forEach(([x, z, v], i) => danfo(x, z, Math.PI / 2 + (i % 2 ? Math.PI : 0), v, i === 3))
  danfo(-20, 32, 0, 3)
  danfo(24, 30.5, Math.PI, 0, true)

  // ---------- footbridge over the road ----------
  const bz = -12
  b.add('metal', M.metal, new THREE.BoxGeometry(44, 0.5, 3.2), 0, 6.2, bz)
  b.add('metal', M.metal, new THREE.BoxGeometry(44, 1.1, 0.12), 0, 7, bz - 1.55)
  b.add('metal', M.metal, new THREE.BoxGeometry(44, 1.1, 0.12), 0, 7, bz + 1.55)
  for (let x = -20; x <= 20; x += 2.5) b.add('metal', M.metal, new THREE.BoxGeometry(0.1, 1.6, 3.2), x, 7.2, bz)
  for (const x of [-21, -9.5, 9.5, 21]) b.solid('metal', M.metal, 0.8, 6, 0.8, x, 0, bz)
  const bsign = new THREE.Mesh(new THREE.PlaneGeometry(10, 2), signs[4])
  bsign.position.set(0, 5.2, bz + 1.65)
  group.add(bsign)
  const bsign2 = bsign.clone()
  bsign2.position.z = bz - 1.65
  bsign2.rotation.y = Math.PI
  group.add(bsign2)

  // ---------- west market: rows of stalls ----------
  const stallCols = [-50, -41, -32, -23, -14]
  stallCols.forEach((cx, ci) => {
    for (let z = -50; z < 24; z += 3.8) {
      if ((Math.round((z + 50) / 3.8) + ci) % 5 === 3) continue // cross aisles
      if (Math.abs(z - bz) < 3) continue
      if (r() < 0.12) continue
      const zinc = M.zinc[Math.floor(r() * M.zinc.length)]
      const zi = M.zinc.indexOf(zinc)
      b.solid('wood', M.wood, 0.12, 2.4, 3.6, cx, 0, z) // shared back wall
      b.solid('darkWood', M.darkWood, 0.9, 1.0, 3.2, cx - 1.7, 0, z)
      b.solid('darkWood', M.darkWood, 0.9, 1.0, 3.2, cx + 1.7, 0, z)
      for (const sx of [-2.1, 2.1])
        for (const sz of [-1.7, 1.7]) b.add('pole', M.pole, new THREE.BoxGeometry(0.08, 2.7, 0.08), cx + sx, 1.35, z + sz)
      b.add(`zinc${zi}`, zinc, new THREE.BoxGeometry(2.4, 0.05, 3.8), cx - 1.15, 2.75, z, 0, 0, 0.18)
      b.add(`zinc${zi}`, zinc, new THREE.BoxGeometry(2.4, 0.05, 3.8), cx + 1.15, 2.75, z, 0, 0, -0.18)
      for (let k = 0; k < 4; k++) {
        const gm = M.goods[Math.floor(r() * M.goods.length)]
        const s = 0.25 + r() * 0.3
        b.add(`goods${M.goods.indexOf(gm)}`, gm, new THREE.BoxGeometry(s, s, s), cx + (k < 2 ? -1.7 : 1.7) + (r() - 0.5) * 0.4, 1 + s / 2, z + (r() - 0.5) * 2.4, 0, r())
      }
    }
  })

  // ---------- east yard: containers, sandbags, barrels ----------
  const container = (x: number, z: number, rotated: boolean, y0 = 0) => {
    const m = M.containers[Math.floor(r() * M.containers.length)]
    const [w, d] = rotated ? [2.4, 6] : [6, 2.4]
    b.solid(`cont${M.containers.indexOf(m)}`, m, w, 2.6, d, x, y0, z, 2.6)
  }
  container(20, -46, false)
  container(20, -46, false, 2.6)
  container(28, -46, false)
  container(44, -44, true)
  container(48, -44, true)
  container(48, -44, true, 2.6)
  container(18, -28, true)
  container(32, -24, false)
  container(32, -21.6, false)
  container(46, -18, true)
  container(16, 8, true)
  container(16, 8, true, 2.6)
  container(40, 12, false)
  container(52, 4, true)
  container(28, 48, false)
  container(44, 50, true)
  container(-44, 48, false)
  container(-30, 52, true)

  const sandbags = (x: number, z: number, rotated: boolean, len = 3) => b.solid('sandbag', M.sandbag, rotated ? 0.7 : len, 0.95, rotated ? len : 0.7, x, 0, z, 1)
  sandbags(26, -8, false)
  sandbags(36, -6, true)
  sandbags(30, 16, false, 4)
  sandbags(48, 24, true)
  sandbags(22, 22, true)
  sandbags(-8.5, -30, true)
  sandbags(8.5, 28, true)
  sandbags(-30, 40, false, 4)
  sandbags(-50, 30, false)
  sandbags(10, -52, false)
  sandbags(40, 40, false, 4)

  const barrel = (x: number, z: number) => {
    const m = r() > 0.5 ? M.barrelBlue : M.barrelRust
    b.add(m === M.barrelBlue ? 'bblue' : 'brust', m, new THREE.CylinderGeometry(0.35, 0.35, 1.0, 12), x, 0.5, z)
    b.collide(x, z, 0.7, 0.7, 0, 1)
  }
  for (const [x, z] of [
    [24, -38],
    [24.8, -38.6],
    [38, -30],
    [52, -10],
    [12, 40],
    [-10, 40],
    [-52, -54],
    [36, 2],
    [36.8, 2.6],
    [-38, 28],
  ])
    barrel(x, z)

  const crate = (x: number, z: number, s = 1.1, y0 = 0) => b.solid('wood', M.wood, s, s, s, x, y0, z)
  crate(30, -36)
  crate(31.2, -36)
  crate(30.6, -36, 1, 1.1)
  crate(42, -2)
  crate(50, 30)
  crate(18, 36)
  crate(-36, 46)
  crate(-24, 36)

  // shacks / buka
  b.solid('wall2', M.walls[2], 6, 3.2, 5, 34, 0, 26, 3.2)
  b.add('zinc1', M.zinc[1], new THREE.BoxGeometry(6.6, 0.1, 5.6), 34, 3.3, 26)
  const buka = new THREE.Mesh(new THREE.PlaneGeometry(5, 1.8), signs[2])
  buka.position.set(34, 2.2, 28.55)
  group.add(buka)
  b.solid('wall0', M.walls[0], 5, 3.2, 5, -40, 0, 36, 3.2)
  b.add('zinc0', M.zinc[0], new THREE.BoxGeometry(5.6, 0.1, 5.6), -40, 3.3, 36)
  b.solid('wall4', M.walls[4], 6, 3.2, 4, 46, 0, -30, 3.2)
  b.solid('metal', M.metal, 1.8, 1.3, 1.1, -24, 0, 44) // generator
  b.solid('metal', M.metal, 1.8, 1.3, 1.1, 50, 0, -36)

  // ---------- power poles and sagging wires ----------
  const wirePts: number[] = []
  const poles: THREE.Vector3[] = []
  for (let z = -54; z <= 54; z += 13.5) poles.push(new THREE.Vector3(-8.5, 0, z))
  for (let z = -54; z <= 54; z += 13.5) poles.push(new THREE.Vector3(8.5, 0, z))
  for (const p of poles) {
    b.add('pole', M.pole, new THREE.CylinderGeometry(0.12, 0.16, 9, 8), p.x, 4.5, p.z)
    b.add('pole', M.pole, new THREE.BoxGeometry(1.6, 0.12, 0.12), p.x, 8.4, p.z)
    b.collide(p.x, p.z, 0.32, 0.32, 0, 9)
  }
  const half = poles.length / 2
  for (let i = 0; i < poles.length - 1; i++) {
    if (i === half - 1) continue
    const a = poles[i]
    const c = poles[i + 1]
    for (const off of [-0.7, 0, 0.7]) {
      const curve = new THREE.QuadraticBezierCurve3(new THREE.Vector3(a.x + off, 8.4, a.z), new THREE.Vector3(a.x + off, 7.2, (a.z + c.z) / 2), new THREE.Vector3(c.x + off, 8.4, c.z))
      const pts = curve.getPoints(8)
      for (let k = 0; k < pts.length - 1; k++) wirePts.push(pts[k].x, pts[k].y, pts[k].z, pts[k + 1].x, pts[k + 1].y, pts[k + 1].z)
    }
  }
  const wireGeo = new THREE.BufferGeometry()
  wireGeo.setAttribute('position', new THREE.Float32BufferAttribute(wirePts, 3))
  group.add(new THREE.LineSegments(wireGeo, new THREE.LineBasicMaterial({ color: '#111' })))

  b.build(group)

  // ---------- sky, sun and atmosphere ----------
  const sunDir = new THREE.Vector3(-0.55, 0.32, -0.6).normalize()
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(450, 32, 16),
    new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: { sun: { value: sunDir } },
      vertexShader: 'varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: `varying vec3 vDir; uniform vec3 sun;
        void main(){
          float h = clamp(vDir.y, -0.1, 1.0);
          vec3 top = vec3(0.16,0.2,0.36);
          vec3 mid = vec3(0.85,0.5,0.32);
          vec3 hor = vec3(1.0,0.72,0.45);
          vec3 col = mix(hor, mid, smoothstep(0.0, 0.12, h));
          col = mix(col, top, smoothstep(0.12, 0.6, h));
          float s = max(dot(normalize(vDir), sun), 0.0);
          col += vec3(1.0,0.6,0.3) * pow(s, 8.0) * 0.6 + vec3(1.0,0.9,0.7) * pow(s, 400.0) * 2.0;
          gl_FragColor = vec4(col, 1.0);
        }`,
    }),
  )
  group.add(sky)

  const hemi = new THREE.HemisphereLight('#9fb4d6', '#5a3a26', 1.1)
  group.add(hemi)
  const sun = new THREE.DirectionalLight('#ffb878', 3.2)
  sun.position.copy(sunDir).multiplyScalar(120)
  sun.castShadow = true
  sun.shadow.mapSize.set(2048, 2048)
  const sc = sun.shadow.camera
  sc.left = sc.bottom = -80
  sc.right = sc.top = 80
  sc.near = 10
  sc.far = 300
  sun.shadow.bias = -0.0004
  sun.shadow.normalBias = 0.04
  group.add(sun)

  // burning wreck: flickering light + rising smoke
  const fireLight = new THREE.PointLight('#ff7a2a', 30, 18, 2)
  fireLight.position.set(3.5, 3, 2)
  group.add(fireLight)
  const glow = glowTexture()
  const smokeTex = glowTexture('rgba(70,60,55,0.7)', 'rgba(40,35,30,0)')
  const fire = new THREE.Sprite(new THREE.SpriteMaterial({ map: glow, color: '#ff8a3a', blending: THREE.AdditiveBlending, depthWrite: false }))
  fire.position.set(3.5, 2.6, 2)
  fire.scale.set(3, 3, 1)
  group.add(fire)
  const smoke: THREE.Sprite[] = []
  const smokeSources = [new THREE.Vector3(3.5, 2.6, 2), new THREE.Vector3(24, 2.4, 30.5), new THREE.Vector3(-90, 10, -140)]
  for (let i = 0; i < 36; i++) {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: smokeTex, depthWrite: false, transparent: true }))
    s.userData = { src: smokeSources[i % 3], life: r() * 8, big: i % 3 === 2 }
    smoke.push(s)
    group.add(s)
  }

  // ---------- navigation points for bots ----------
  const nav: THREE.Vector3[] = []
  const test = new THREE.Box3()
  for (let x = -BOUNDS + 2; x <= BOUNDS - 2; x += 3)
    for (let z = -BOUNDS + 2; z <= BOUNDS - 2; z += 3) {
      test.min.set(x - 0.9, 0.1, z - 0.9)
      test.max.set(x + 0.9, 1.8, z + 0.9)
      if (!b.colliders.some((c) => c.intersectsBox(test))) nav.push(new THREE.Vector3(x, 0, z))
    }

  return {
    group,
    colliders: b.colliders,
    nav,
    bounds: BOUNDS,
    sunDir,
    update(dt, t) {
      fireLight.intensity = 26 + Math.sin(t * 17) * 6 + Math.sin(t * 7.3) * 5
      fire.scale.setScalar(2.6 + Math.sin(t * 11) * 0.4)
      for (const s of smoke) {
        const u = s.userData as { src: THREE.Vector3; life: number; big: boolean }
        u.life += dt
        if (u.life > 8) u.life = 0
        const k = u.life / 8
        const scale = u.big ? 30 : 4
        s.position.set(u.src.x + Math.sin(u.life * 0.7 + u.src.z) * 1.5 + k * 4, u.src.y + k * (u.big ? 60 : 16), u.src.z + k * 3)
        s.scale.setScalar(scale * (0.5 + k * 1.6))
        ;(s.material as THREE.SpriteMaterial).opacity = Math.sin(k * Math.PI) * 0.8
      }
    },
  }
}
