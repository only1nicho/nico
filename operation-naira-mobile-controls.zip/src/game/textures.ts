import * as THREE from 'three'

/** Seeded PRNG so the procedural world looks the same on every load. */
export function rng(seed = 1) {
  let s = seed >>> 0
  return () => {
    s = (s + 0x6d2b79f5) >>> 0
    let t = s
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function canvas(size: number) {
  const c = document.createElement('canvas')
  c.width = c.height = size
  return [c, c.getContext('2d')!] as const
}

function finish(c: HTMLCanvasElement, repeat = true) {
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.anisotropy = 8
  return t
}

function speckle(ctx: CanvasRenderingContext2D, size: number, count: number, colors: string[], r: () => number, maxR = 2) {
  for (let i = 0; i < count; i++) {
    ctx.fillStyle = colors[Math.floor(r() * colors.length)]
    ctx.globalAlpha = 0.15 + r() * 0.35
    const rad = 0.5 + r() * maxR
    ctx.beginPath()
    ctx.arc(r() * size, r() * size, rad, 0, Math.PI * 2)
    ctx.fill()
  }
  ctx.globalAlpha = 1
}

/** Red laterite earth, the ground of half of Nigeria. */
export function lateriteTexture() {
  const [c, ctx] = canvas(512)
  const r = rng(7)
  ctx.fillStyle = '#8a4a2c'
  ctx.fillRect(0, 0, 512, 512)
  speckle(ctx, 512, 5000, ['#6e3820', '#a35c37', '#5a2e1a', '#b8714a', '#7c5a3c'], r, 3)
  for (let i = 0; i < 40; i++) {
    ctx.fillStyle = r() > 0.5 ? 'rgba(60,30,15,0.18)' : 'rgba(190,130,90,0.12)'
    ctx.beginPath()
    ctx.ellipse(r() * 512, r() * 512, 20 + r() * 60, 10 + r() * 30, r() * 3, 0, Math.PI * 2)
    ctx.fill()
  }
  return finish(c)
}

export function asphaltTexture() {
  const [c, ctx] = canvas(512)
  const r = rng(11)
  ctx.fillStyle = '#3a3936'
  ctx.fillRect(0, 0, 512, 512)
  speckle(ctx, 512, 7000, ['#2a2a28', '#4a4945', '#55524c', '#222'], r, 1.6)
  ctx.strokeStyle = 'rgba(15,15,15,0.5)'
  for (let i = 0; i < 12; i++) {
    ctx.lineWidth = 1 + r() * 2
    ctx.beginPath()
    let x = r() * 512
    let y = r() * 512
    ctx.moveTo(x, y)
    for (let j = 0; j < 6; j++) {
      x += (r() - 0.5) * 60
      y += (r() - 0.5) * 60
      ctx.lineTo(x, y)
    }
    ctx.stroke()
  }
  return finish(c)
}

/** Painted concrete facade with one barred window per 3m tile. */
export function wallTexture(base: string, seed: number) {
  const [c, ctx] = canvas(256)
  const r = rng(seed)
  ctx.fillStyle = base
  ctx.fillRect(0, 0, 256, 256)
  speckle(ctx, 256, 1400, ['#000', '#fff', '#5a4a3a'], r, 2)
  // rain streaks
  for (let i = 0; i < 14; i++) {
    const x = r() * 256
    const g = ctx.createLinearGradient(0, 0, 0, 256)
    g.addColorStop(0, 'rgba(40,30,20,0.35)')
    g.addColorStop(1, 'rgba(40,30,20,0)')
    ctx.fillStyle = g
    ctx.fillRect(x, 0, 3 + r() * 6, 80 + r() * 170)
  }
  // window
  ctx.fillStyle = '#1b1d20'
  ctx.fillRect(78, 70, 100, 110)
  ctx.fillStyle = 'rgba(120,140,150,0.25)'
  ctx.fillRect(84, 76, 88, 98)
  ctx.strokeStyle = '#2b2b2b'
  ctx.lineWidth = 4
  for (let x = 92; x < 175; x += 14) {
    ctx.beginPath()
    ctx.moveTo(x, 70)
    ctx.lineTo(x, 180)
    ctx.stroke()
  }
  ctx.fillStyle = 'rgba(0,0,0,0.35)'
  ctx.fillRect(70, 180, 116, 8)
  // floor slab line
  ctx.fillStyle = 'rgba(0,0,0,0.25)'
  ctx.fillRect(0, 250, 256, 6)
  return finish(c)
}

export function concreteTexture(seed = 3) {
  const [c, ctx] = canvas(256)
  const r = rng(seed)
  ctx.fillStyle = '#8d8a82'
  ctx.fillRect(0, 0, 256, 256)
  speckle(ctx, 256, 2500, ['#6b6862', '#a29f97', '#58554f'], r, 2)
  return finish(c)
}

/** Corrugated zinc / tarp roofing. */
export function corrugatedTexture(base: string, seed: number) {
  const [c, ctx] = canvas(256)
  const r = rng(seed)
  ctx.fillStyle = base
  ctx.fillRect(0, 0, 256, 256)
  for (let x = 0; x < 256; x += 16) {
    const g = ctx.createLinearGradient(x, 0, x + 16, 0)
    g.addColorStop(0, 'rgba(255,255,255,0.12)')
    g.addColorStop(0.5, 'rgba(0,0,0,0.25)')
    g.addColorStop(1, 'rgba(255,255,255,0.12)')
    ctx.fillStyle = g
    ctx.fillRect(x, 0, 16, 256)
  }
  speckle(ctx, 256, 900, ['#5a2a10', '#8a4a1a', '#3a2a20'], r, 4)
  return finish(c)
}

export function sandbagTexture() {
  const [c, ctx] = canvas(256)
  const r = rng(5)
  ctx.fillStyle = '#9c8a62'
  ctx.fillRect(0, 0, 256, 256)
  for (let row = 0; row < 4; row++) {
    for (let col = -1; col < 4; col++) {
      const x = col * 72 + (row % 2) * 36
      const y = row * 64
      ctx.fillStyle = `rgba(${150 + r() * 30},${130 + r() * 25},${90 + r() * 20},1)`
      ctx.beginPath()
      ctx.roundRect(x + 2, y + 3, 68, 58, 18)
      ctx.fill()
      ctx.strokeStyle = 'rgba(60,45,25,0.6)'
      ctx.lineWidth = 3
      ctx.stroke()
    }
  }
  speckle(ctx, 256, 800, ['#5a4a2a', '#c9b98f'], r, 1.5)
  return finish(c)
}

export function containerTexture(base: string, seed: number) {
  const [c, ctx] = canvas(256)
  const r = rng(seed)
  ctx.fillStyle = base
  ctx.fillRect(0, 0, 256, 256)
  for (let x = 0; x < 256; x += 12) {
    ctx.fillStyle = 'rgba(0,0,0,0.22)'
    ctx.fillRect(x, 0, 3, 256)
    ctx.fillStyle = 'rgba(255,255,255,0.08)'
    ctx.fillRect(x + 5, 0, 2, 256)
  }
  speckle(ctx, 256, 1200, ['#6a3a1a', '#3a2010', '#8a5a2a'], r, 3)
  return finish(c)
}

const SLOGANS = ['NO FOOD FOR LAZY MAN', 'GOD DEY', 'NO KING AS GOD', 'OSHODI – OBALENDE', 'EKO O NI BAJE', 'FOLLOW COME']

/** Yellow danfo bus side panel with the iconic black stripes and a hand-painted slogan. */
export function danfoTexture(variant: number) {
  const c = document.createElement('canvas')
  c.width = 512
  c.height = 256
  const ctx = c.getContext('2d')!
  const r = rng(100 + variant)
  ctx.fillStyle = '#e8b80c'
  ctx.fillRect(0, 0, 512, 256)
  // windows
  ctx.fillStyle = '#1c2228'
  for (let x = 30; x < 470; x += 92) ctx.fillRect(x, 26, 78, 80)
  ctx.fillStyle = 'rgba(160,190,210,0.18)'
  for (let x = 30; x < 470; x += 92) ctx.fillRect(x + 4, 30, 34, 72)
  // stripes
  ctx.fillStyle = '#111'
  ctx.fillRect(0, 128, 512, 12)
  ctx.fillRect(0, 150, 512, 12)
  // slogan
  ctx.fillStyle = '#b5121b'
  ctx.font = 'bold 26px Impact, sans-serif'
  ctx.textAlign = 'center'
  ctx.fillText(SLOGANS[variant % SLOGANS.length], 256, 200)
  // rust and dust
  speckle(ctx, 512, 1500, ['#7a4a10', '#4a3010', '#c09a40'], r, 3)
  const g = ctx.createLinearGradient(0, 180, 0, 256)
  g.addColorStop(0, 'rgba(90,50,20,0)')
  g.addColorStop(1, 'rgba(90,50,20,0.55)')
  ctx.fillStyle = g
  ctx.fillRect(0, 180, 512, 76)
  return finish(c, false)
}

/** Hand-painted roadside signage. */
export function signTexture(text: string, sub: string, bg: string, fg: string) {
  const c = document.createElement('canvas')
  c.width = 512
  c.height = 192
  const ctx = c.getContext('2d')!
  const r = rng(text.length * 31)
  ctx.fillStyle = bg
  ctx.fillRect(0, 0, 512, 192)
  ctx.strokeStyle = fg
  ctx.lineWidth = 8
  ctx.strokeRect(10, 10, 492, 172)
  ctx.fillStyle = fg
  ctx.textAlign = 'center'
  ctx.font = 'bold 58px Impact, sans-serif'
  ctx.fillText(text, 256, 92)
  ctx.font = 'bold 28px Arial, sans-serif'
  ctx.fillText(sub, 256, 148)
  speckle(ctx, 512, 900, ['#000', '#5a3a20'], r, 3)
  return finish(c, false)
}

/** Camo pattern for uniforms. */
export function camoTexture(colors: string[], seed: number) {
  const [c, ctx] = canvas(128)
  const r = rng(seed)
  ctx.fillStyle = colors[0]
  ctx.fillRect(0, 0, 128, 128)
  for (let i = 0; i < 60; i++) {
    ctx.fillStyle = colors[1 + Math.floor(r() * (colors.length - 1))]
    ctx.beginPath()
    ctx.ellipse(r() * 128, r() * 128, 4 + r() * 14, 3 + r() * 8, r() * 3, 0, Math.PI * 2)
    ctx.fill()
  }
  return finish(c)
}

/** Soft radial sprite used for muzzle flashes, sparks and smoke. */
export function glowTexture(inner = 'rgba(255,240,200,1)', outer = 'rgba(255,140,30,0)') {
  const [c, ctx] = canvas(64)
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32)
  g.addColorStop(0, inner)
  g.addColorStop(0.3, 'rgba(255,190,80,0.8)')
  g.addColorStop(1, outer)
  ctx.fillStyle = g
  ctx.fillRect(0, 0, 64, 64)
  return finish(c, false)
}

export function decalTexture() {
  const [c, ctx] = canvas(64)
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 30)
  g.addColorStop(0, 'rgba(0,0,0,0.95)')
  g.addColorStop(0.35, 'rgba(20,15,10,0.8)')
  g.addColorStop(1, 'rgba(40,30,20,0)')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, 64, 64)
  return finish(c, false)
}
