import * as THREE from 'three'
import { BOT_NAMES, MATCH_KILL_TARGET, MATCH_SECONDS, STREAK_CALLOUTS, type WeaponStats } from '@/data/game'
import { GameAudio } from './audio'
import { buildArms, buildSoldier, buildWeaponModel, type SoldierModel, type WeaponModel } from './models'
import { camoTexture, decalTexture, glowTexture } from './textures'
import { buildOshodi, type World } from './world'

export type Difficulty = 'recruit' | 'regular' | 'veteran'

export interface BoardRow {
  name: string
  kills: number
  deaths: number
  you: boolean
}

export interface HudState {
  health: number
  ammo: number
  reserve: number
  mag: number
  weaponName: string
  weaponNick: string
  slot: 0 | 1
  reloading: number
  kills: number
  deaths: number
  score: number
  streak: number
  timeLeft: number
  spread: number
  scoped: boolean
  ads: number
  alive: boolean
  respawnIn: number
  board: BoardRow[]
  showBoard: boolean
}

export interface KillEntry {
  id: number
  killer: string
  victim: string
  weapon: string
  headshot: boolean
  you: 'killer' | 'victim' | null
}

export interface MatchStats {
  kills: number
  deaths: number
  headshots: number
  accuracy: number
  score: number
  bestStreak: number
  naira: number
  xp: number
  placement: number
  players: number
  seconds: number
}

export interface EngineCallbacks {
  onHud(s: HudState): void
  onHitMarker(kind: 'body' | 'head' | 'kill'): void
  onKillFeed(e: KillEntry): void
  onDamage(angleRad: number): void
  onLock(locked: boolean): void
  onEnd(stats: MatchStats): void
  onCallout(text: string): void
}

export interface EngineOptions {
  primary: WeaponStats
  secondary: WeaponStats
  difficulty: Difficulty
  sensitivity: number
}

interface Gun {
  stats: WeaponStats
  model: WeaponModel
  ammo: number
  reserve: number
  flash: THREE.Sprite
}

interface Bot {
  model: SoldierModel
  flash: THREE.Sprite
  name: string
  health: number
  alive: boolean
  pos: THREE.Vector3
  yaw: number
  target: THREE.Vector3 | null
  lastSeen: THREE.Vector3 | null
  canSee: boolean
  seeT: number
  reaction: number
  nextLos: number
  nextShot: number
  burstLeft: number
  strafe: number
  strafeT: number
  deadT: number
  kills: number
  deaths: number
  revealT: number
  walk: number
  stuckT: number
  stuckFrom: THREE.Vector3
  flashT: number
}

interface Fx {
  obj: THREE.Object3D
  life: number
  max: number
  vel?: THREE.Vector3
}

const STEP = 0.45
const PLAYER_R = 0.35
const GRAVITY = 22
const HIP = new THREE.Vector3(0.15, -0.16, -0.36)

const DIFF = {
  recruit: { bots: 6, acc: 0.22, dmg: 8, reaction: 0.9 },
  regular: { bots: 8, acc: 0.34, dmg: 11, reaction: 0.6 },
  veteran: { bots: 9, acc: 0.46, dmg: 14, reaction: 0.4 },
}

export class Engine {
  private renderer: THREE.WebGLRenderer
  private scene = new THREE.Scene()
  private camera: THREE.PerspectiveCamera
  private vmScene = new THREE.Scene()
  private vmCamera: THREE.PerspectiveCamera
  private world: World
  private audio = new GameAudio()
  private clock = new THREE.Clock()
  private time = 0
  private elapsed = 0

  // player
  private pos = new THREE.Vector3()
  private vel = new THREE.Vector3()
  private yaw = 0
  private pitch = 0
  private onGround = true
  private crouchT = 0
  private health = 100
  private lastHurt = -10
  private alive = true
  private respawnAt = 0
  private adsT = 0
  private bob = 0
  private kick = 0
  private bloom = 0
  private sway = new THREE.Vector2()
  private keys = new Set<string>()
  private trigger = false
  private adsHeld = false
  private showBoard = false
  private locked = false
  private ended = false
  private sprinting = false
  private mobileActive = false
  private touchMoveX = 0
  private touchMoveY = 0

  // weapons
  private guns: Gun[]
  private current: 0 | 1 = 0
  private switchT = 0
  private pendingSlot: 0 | 1 = 0
  private reloadT = 0
  private reloadDur = 1
  private lastShot = -10
  private gunHolder = new THREE.Group()
  private arms: THREE.Group
  private flashLight = new THREE.PointLight('#ffb060', 0, 10, 2)

  // stats
  private kills = 0
  private deaths = 0
  private headshots = 0
  private shots = 0
  private hits = 0
  private score = 0
  private streak = 0
  private bestStreak = 0
  private firstBlood = false
  private feedId = 0

  private bots: Bot[] = []
  private fx: Fx[] = []
  private decals: THREE.Mesh[] = []
  private decalIdx = 0
  private sparkPool: THREE.Sprite[] = []
  private bloodPool: THREE.Sprite[] = []
  private tracerPool: THREE.Mesh[] = []
  private poolIdx = { spark: 0, blood: 0, tracer: 0 }

  private ray = new THREE.Ray()
  private raycaster = new THREE.Raycaster()
  private tmp = new THREE.Vector3()
  private tmp2 = new THREE.Vector3()
  private hudTimer = 0
  private mapTimer = 0
  private diff: (typeof DIFF)[Difficulty]
  private sens: number

  constructor(
    private container: HTMLElement,
    private minimap: HTMLCanvasElement,
    opts: EngineOptions,
    private cb: EngineCallbacks,
  ) {
    this.diff = DIFF[opts.difficulty]
    this.sens = opts.sensitivity

    const r = (this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' }))
    r.setPixelRatio(Math.min(window.devicePixelRatio, 1.5))
    r.setSize(container.clientWidth, container.clientHeight)
    r.shadowMap.enabled = true
    r.shadowMap.type = THREE.PCFSoftShadowMap
    r.toneMapping = THREE.ACESFilmicToneMapping
    r.toneMappingExposure = 1.05
    r.outputColorSpace = THREE.SRGBColorSpace
    r.autoClear = false
    container.appendChild(r.domElement)
    r.domElement.style.display = 'block'
    r.domElement.style.touchAction = 'none'

    const aspect = container.clientWidth / container.clientHeight
    this.camera = new THREE.PerspectiveCamera(75, aspect, 0.05, 700)
    this.camera.rotation.order = 'YXZ'
    this.vmCamera = new THREE.PerspectiveCamera(55, aspect, 0.01, 10)

    this.scene.fog = new THREE.FogExp2('#c4977a', 0.0105)
    this.world = buildOshodi()
    this.scene.add(this.world.group)
    this.scene.add(this.flashLight)

    // viewmodel scene
    this.vmScene.add(new THREE.HemisphereLight('#b8c8e0', '#5a3a26', 1.4))
    const vmSun = new THREE.DirectionalLight('#ffc28a', 2.2)
    vmSun.position.set(-1, 1.2, 0.6)
    this.vmScene.add(vmSun)
    this.vmScene.add(this.gunHolder)

    const flashTex = glowTexture()
    const camoNg = camoTexture(['#4a5a32', '#2e3a20', '#6b6a44', '#1f2616'], 77)
    this.arms = buildArms(camoNg)
    this.guns = [opts.primary, opts.secondary].map((stats) => {
      const model = buildWeaponModel(stats, stats.attachments)
      model.group.traverse((o) => (o.castShadow = false))
      const flash = new THREE.Sprite(new THREE.SpriteMaterial({ map: flashTex, blending: THREE.AdditiveBlending, depthWrite: false, color: '#ffd8a0' }))
      flash.scale.setScalar(0.18)
      flash.visible = false
      model.muzzle.add(flash)
      return { stats, model, ammo: stats.mag, reserve: stats.reserve, flash }
    })
    this.equip(0)

    // bots
    const camoMilitia = camoTexture(['#3b3a2e', '#5a4a32', '#22231c', '#6b5a3c'], 13)
    const accents = ['#b5121b', '#c4161c', '#8a1010']
    for (let i = 0; i < this.diff.bots; i++) {
      const model = buildSoldier(camoMilitia, accents[i % accents.length])
      const flash = new THREE.Sprite(new THREE.SpriteMaterial({ map: flashTex, blending: THREE.AdditiveBlending, depthWrite: false, color: '#ffd8a0' }))
      flash.scale.setScalar(0.5)
      flash.visible = false
      ;(model.gun.userData.tip as THREE.Object3D).add(flash)
      this.scene.add(model.group)
      this.bots.push({
        model,
        flash,
        name: BOT_NAMES[i % BOT_NAMES.length],
        health: 100,
        alive: true,
        pos: new THREE.Vector3(),
        yaw: 0,
        target: null,
        lastSeen: null,
        canSee: false,
        seeT: 0,
        reaction: this.diff.reaction,
        nextLos: Math.random() * 0.3,
        nextShot: 0,
        burstLeft: 0,
        strafe: 0,
        strafeT: 0,
        deadT: 0,
        kills: 0,
        deaths: 0,
        revealT: 0,
        walk: 0,
        stuckT: 0,
        stuckFrom: new THREE.Vector3(),
        flashT: 0,
      })
    }

    // fx pools
    const decalMat = new THREE.MeshBasicMaterial({ map: decalTexture(), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4 })
    const decalGeo = new THREE.PlaneGeometry(0.16, 0.16)
    for (let i = 0; i < 80; i++) {
      const d = new THREE.Mesh(decalGeo, decalMat)
      d.visible = false
      this.decals.push(d)
      this.scene.add(d)
    }
    for (let i = 0; i < 40; i++) {
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: flashTex, blending: THREE.AdditiveBlending, depthWrite: false, color: '#ffc080' }))
      s.visible = false
      this.sparkPool.push(s)
      this.scene.add(s)
      const b = new THREE.Sprite(new THREE.SpriteMaterial({ map: flashTex, depthWrite: false, color: '#6a0a0a', transparent: true }))
      b.visible = false
      this.bloodPool.push(b)
      this.scene.add(b)
    }
    const tracerGeo = new THREE.BoxGeometry(0.015, 0.015, 1)
    tracerGeo.translate(0, 0, 0.5)
    for (let i = 0; i < 24; i++) {
      const t = new THREE.Mesh(tracerGeo, new THREE.MeshBasicMaterial({ color: '#ffd28a', transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }))
      t.visible = false
      this.tracerPool.push(t)
      this.scene.add(t)
    }

    this.spawnPlayer()
    for (const b of this.bots) this.spawnBot(b, 30)

    this.bind()
    this.clock.start()
    r.setAnimationLoop(() => this.frame())
  }

  // ------------------------------------------------------------------ input
  private handlers: [EventTarget, string, EventListener][] = []
  private on<K extends string>(t: EventTarget, type: K, fn: (e: never) => void) {
    t.addEventListener(type, fn as EventListener, { passive: false })
    this.handlers.push([t, type, fn as EventListener])
  }

  private bind() {
    this.on(document, 'pointerlockchange', () => {
      if (this.mobileActive) return
      this.locked = document.pointerLockElement === this.renderer.domElement
      if (!this.locked) {
        this.keys.clear()
        this.trigger = false
        this.adsHeld = false
        this.showBoard = false
      }
      this.clock.getDelta()
      this.cb.onLock(this.locked)
    })
    this.on(document, 'mousemove', (e: MouseEvent) => {
      if (!this.locked) return
      const zoom = this.currentZoom()
      const k = (0.0021 * this.sens) / zoom
      this.yaw -= e.movementX * k
      this.pitch = THREE.MathUtils.clamp(this.pitch - e.movementY * k, -1.5, 1.5)
      this.sway.x = THREE.MathUtils.clamp(this.sway.x - e.movementX * 0.0003, -0.04, 0.04)
      this.sway.y = THREE.MathUtils.clamp(this.sway.y + e.movementY * 0.0003, -0.04, 0.04)
    })
    this.on(document, 'mousedown', (e: MouseEvent) => {
      if (!this.locked) return
      if (e.button === 0) {
        this.trigger = true
        if (!this.gun.stats.auto) this.tryFire()
      }
      if (e.button === 2) this.adsHeld = true
    })
    this.on(document, 'mouseup', (e: MouseEvent) => {
      if (e.button === 0) this.trigger = false
      if (e.button === 2) this.adsHeld = false
    })
    this.on(document, 'contextmenu', (e: Event) => this.locked && e.preventDefault())
    this.on(document, 'wheel', (e: WheelEvent) => {
      if (this.locked && Math.abs(e.deltaY) > 10) this.switchTo(this.current === 0 ? 1 : 0)
    })
    this.on(document, 'keydown', (e: KeyboardEvent) => {
      if (!this.locked) return
      if (['Tab', 'Space'].includes(e.code)) e.preventDefault()
      this.keys.add(e.code)
      if (e.code === 'KeyR') this.startReload()
      if (e.code === 'Digit1') this.switchTo(0)
      if (e.code === 'Digit2') this.switchTo(1)
      if (e.code === 'KeyQ') this.switchTo(this.current === 0 ? 1 : 0)
      if (e.code === 'Tab') this.showBoard = true
      if (e.code === 'Space' && this.onGround && this.alive) {
        this.vel.y = 7.2
        this.onGround = false
      }
    })
    this.on(document, 'keyup', (e: KeyboardEvent) => {
      this.keys.delete(e.code)
      if (e.code === 'Tab') this.showBoard = false
    })
    this.on(window, 'resize', () => this.resize())
  }

  lock() {
    if (this.ended) return
    this.audio.init()
    if (window.matchMedia('(pointer: coarse)').matches) {
      this.mobileActive = true
      this.locked = true
      this.cb.onLock(true)
      return
    }
    void this.renderer.domElement.requestPointerLock()
  }

  setTouchMove(x: number, y: number) {
    this.touchMoveX = THREE.MathUtils.clamp(x, -1, 1)
    this.touchMoveY = THREE.MathUtils.clamp(y, -1, 1)
  }

  touchLook(dx: number, dy: number) {
    if (!this.locked || !this.mobileActive) return
    const k = 0.0042 * this.sens / this.currentZoom()
    this.yaw -= dx * k
    this.pitch = THREE.MathUtils.clamp(this.pitch - dy * k, -1.5, 1.5)
    this.sway.x = THREE.MathUtils.clamp(this.sway.x - dx * 0.0003, -0.04, 0.04)
    this.sway.y = THREE.MathUtils.clamp(this.sway.y + dy * 0.0003, -0.04, 0.04)
  }

  setTouchFire(held: boolean) {
    this.trigger = held
    if (held && !this.gun.stats.auto) this.tryFire()
  }

  setTouchAim(held: boolean) { this.adsHeld = held }
  touchReload() { this.startReload() }
  touchSwitch() { this.switchTo(this.current === 0 ? 1 : 0) }
  touchJump() {
    if (this.onGround && this.alive) {
      this.vel.y = 7.2
      this.onGround = false
    }
  }

  setSensitivity(v: number) {
    this.sens = v
  }

  private resize() {
    const w = this.container.clientWidth
    const h = this.container.clientHeight
    this.renderer.setSize(w, h)
    this.camera.aspect = this.vmCamera.aspect = w / h
    this.camera.updateProjectionMatrix()
    this.vmCamera.updateProjectionMatrix()
  }

  dispose() {
    this.renderer.setAnimationLoop(null)
    for (const [t, type, fn] of this.handlers) t.removeEventListener(type, fn)
    if (document.pointerLockElement === this.renderer.domElement) document.exitPointerLock()
    const disposeObj = (o: THREE.Object3D) =>
      o.traverse((c) => {
        const m = c as THREE.Mesh
        m.geometry?.dispose()
        const mats = Array.isArray(m.material) ? m.material : m.material ? [m.material] : []
        mats.forEach((mt) => {
          ;(mt as THREE.MeshStandardMaterial).map?.dispose()
          mt.dispose()
        })
      })
    disposeObj(this.scene)
    disposeObj(this.vmScene)
    this.renderer.dispose()
    this.renderer.domElement.remove()
    this.audio.dispose()
  }

  // ------------------------------------------------------------------ weapons
  private get gun() {
    return this.guns[this.current]
  }

  private equip(slot: 0 | 1) {
    this.current = slot
    this.gunHolder.clear()
    const g = this.guns[slot]
    this.gunHolder.add(g.model.group, this.arms)
    this.arms.position.set(0, 0, g.stats.class === 'pistol' ? 0.08 : 0)
    this.arms.visible = true
  }

  private switchTo(slot: 0 | 1) {
    if (slot === this.current || this.switchT > 0 || !this.alive) return
    this.reloadT = 0
    this.pendingSlot = slot
    this.switchT = 0.4
    this.audio.click(0.6)
  }

  private startReload() {
    const g = this.gun
    if (this.reloadT > 0 || this.switchT > 0 || g.ammo >= g.stats.mag || g.reserve <= 0 || !this.alive) return
    this.reloadDur = this.reloadT = g.stats.reload
    this.audio.click(0.8)
    this.audio.click(1.2, g.stats.reload * 0.7)
  }

  private currentZoom() {
    const z = this.gun.stats.zoom
    const t = this.adsT * this.adsT * (3 - 2 * this.adsT)
    return 1 + (z - 1) * t
  }

  private moving() {
    return Math.hypot(this.vel.x, this.vel.z) > 0.8
  }

  private spread() {
    const s = this.gun.stats
    let sp = s.hipSpread * (this.moving() ? 1.5 : 1) * (this.onGround ? 1 : 2.2) * (this.crouchT > 0.5 ? 0.75 : 1) + this.bloom
    const adsFactor = s.class === 'sniper' ? 0.01 : 0.12
    sp *= 1 - this.adsT * (1 - adsFactor)
    if (this.sprinting) sp *= 1.8
    return sp
  }

  private tryFire() {
    const g = this.gun
    const s = g.stats
    if (!this.alive || this.switchT > 0 || this.reloadT > 0 || this.ended) return
    if (this.time - this.lastShot < 60 / s.rpm) return
    if (g.ammo <= 0) {
      if (g.reserve > 0) this.startReload()
      else this.audio.click(1.6)
      return
    }
    this.sprinting = false
    g.ammo--
    this.lastShot = this.time
    this.shots++

    // direction with spread
    const sp = this.spread()
    const dir = new THREE.Vector3(0, 0, -1)
    const a = Math.random() * Math.PI * 2
    const m = Math.sqrt(Math.random()) * sp
    dir.x += Math.cos(a) * m
    dir.y += Math.sin(a) * m
    dir.normalize().applyQuaternion(this.camera.quaternion)
    const origin = this.camera.position.clone()

    const wall = this.raycastWorld(origin, dir, 400)
    let bestBot: { bot: Bot; part: string; dist: number; point: THREE.Vector3 } | null = null
    this.raycaster.set(origin, dir)
    this.raycaster.far = wall ? wall.dist : 400
    for (const bot of this.bots) {
      if (!bot.alive) continue
      const hit = this.raycaster.intersectObjects(bot.model.parts, false)[0]
      if (hit && (!bestBot || hit.distance < bestBot.dist)) bestBot = { bot, part: hit.object.userData.part as string, dist: hit.distance, point: hit.point }
    }

    let end: THREE.Vector3
    if (bestBot) {
      end = bestBot.point
      this.damageBot(bestBot.bot, bestBot.part, bestBot.dist)
      this.puff(this.bloodPool, 'blood', end, 3, 0.25)
    } else if (wall) {
      end = wall.point
      this.decal(wall.point, wall.normal)
      this.puff(this.sparkPool, 'spark', wall.point, 3, 0.12, wall.normal)
    } else {
      end = origin.clone().addScaledVector(dir, 200)
    }

    // recoil & feedback
    const rec = s.recoil * (1 - this.adsT * 0.3) * (this.crouchT > 0.5 ? 0.8 : 1) * (0.8 + Math.random() * 0.4)
    this.pitch = Math.min(1.5, this.pitch + rec)
    this.yaw += (Math.random() - 0.5) * rec * 0.6
    this.bloom = Math.min(s.hipSpread * 1.5, this.bloom + s.recoil * 0.5)
    this.kick = 1
    this.audio.shot(s.class, s.suppressed)
    if (!s.suppressed) {
      g.flash.visible = true
      g.flash.material.rotation = Math.random() * Math.PI
      g.flash.scale.setScalar(0.12 + Math.random() * 0.12)
      this.flashLight.intensity = 6
    }
    this.flashLight.position.copy(origin).addScaledVector(dir, 1)
    if (this.shots % 2 === 0 || !s.auto) {
      const right = this.tmp.set(1, 0, 0).applyQuaternion(this.camera.quaternion)
      const start = origin.clone().addScaledVector(dir, 0.8).addScaledVector(right, 0.12).add(this.tmp2.set(0, -0.1, 0))
      this.tracer(start, end, s.suppressed ? 0.25 : 0.8)
    }
    // gunfire alerts nearby bots
    const hearing = s.suppressed ? 12 : 45
    for (const b of this.bots) if (b.alive && b.pos.distanceTo(this.pos) < hearing && !b.canSee) b.lastSeen = this.pos.clone()
    if (g.ammo === 0 && g.reserve > 0) setTimeout(() => this.startReload(), 150)
  }

  private damageBot(bot: Bot, part: string, dist: number) {
    const s = this.gun.stats
    const mult = part === 'head' ? (s.class === 'sniper' ? 2.6 : 1.8) : part === 'legs' ? 0.8 : 1
    const falloff = dist > s.range ? Math.max(0.55, 1 - (dist - s.range) / (s.range * 1.5)) : 1
    bot.health -= s.damage * mult * falloff
    bot.lastSeen = this.pos.clone()
    bot.seeT = Math.max(bot.seeT, bot.reaction * 0.5)
    this.hits++
    const head = part === 'head'
    if (bot.health <= 0) {
      bot.alive = false
      bot.deadT = 0
      bot.deaths++
      bot.flash.visible = false
      this.kills++
      this.streak++
      this.bestStreak = Math.max(this.bestStreak, this.streak)
      this.score += 100 + (head ? 50 : 0) + (this.streak >= 3 ? 25 : 0)
      if (head) this.headshots++
      this.cb.onHitMarker('kill')
      this.audio.hit(head, true)
      this.cb.onKillFeed({ id: ++this.feedId, killer: 'You', victim: bot.name, weapon: s.nickname, headshot: head, you: 'killer' })
      if (!this.firstBlood) {
        this.firstBlood = true
        this.cb.onCallout('FIRST BLOOD · OYA!')
      } else if (STREAK_CALLOUTS[this.streak]) this.cb.onCallout(STREAK_CALLOUTS[this.streak])
      else if (head) this.cb.onCallout('HEADSHOT')
      if (this.kills >= MATCH_KILL_TARGET) this.endMatch()
    } else {
      this.cb.onHitMarker(head ? 'head' : 'body')
      this.audio.hit(head, false)
    }
  }

  // ------------------------------------------------------------------ physics helpers
  private raycastWorld(origin: THREE.Vector3, dir: THREE.Vector3, max: number) {
    this.ray.set(origin, dir)
    let best = max
    let box: THREE.Box3 | null = null
    const p = new THREE.Vector3()
    for (const c of this.world.colliders) {
      if (this.ray.intersectBox(c, p)) {
        const d = p.distanceTo(origin)
        if (d < best) {
          best = d
          box = c
        }
      }
    }
    if (dir.y < -1e-4) {
      const tg = -origin.y / dir.y
      if (tg < best) return { dist: tg, point: origin.clone().addScaledVector(dir, tg), normal: new THREE.Vector3(0, 1, 0) }
    }
    if (!box) return null
    const point = origin.clone().addScaledVector(dir, best)
    const normal = new THREE.Vector3()
    const faces: [number, THREE.Vector3][] = [
      [Math.abs(point.x - box.min.x), new THREE.Vector3(-1, 0, 0)],
      [Math.abs(point.x - box.max.x), new THREE.Vector3(1, 0, 0)],
      [Math.abs(point.y - box.min.y), new THREE.Vector3(0, -1, 0)],
      [Math.abs(point.y - box.max.y), new THREE.Vector3(0, 1, 0)],
      [Math.abs(point.z - box.min.z), new THREE.Vector3(0, 0, -1)],
      [Math.abs(point.z - box.max.z), new THREE.Vector3(0, 0, 1)],
    ]
    faces.sort((a, b) => a[0] - b[0])
    normal.copy(faces[0][1])
    return { dist: best, point, normal }
  }

  private blocked(from: THREE.Vector3, to: THREE.Vector3) {
    const dir = this.tmp2.subVectors(to, from)
    const dist = dir.length()
    dir.divideScalar(dist)
    const hit = this.raycastWorld(from, dir.clone(), dist)
    return !!hit && hit.dist < dist - 0.3
  }

  /** Moves a circle of radius r along XZ with axis-separated collision against world boxes. */
  private moveCircle(p: THREE.Vector3, dx: number, dz: number, r: number, h: number) {
    const cols = this.world.colliders
    const axis = (ax: 'x' | 'z', amt: number) => {
      if (!amt) return false
      p[ax] += amt
      let hit = false
      for (const c of cols) {
        if (c.max.y <= p.y + STEP || c.min.y >= p.y + h) continue
        if (p.x + r > c.min.x && p.x - r < c.max.x && p.z + r > c.min.z && p.z - r < c.max.z) {
          p[ax] = amt > 0 ? c.min[ax] - r - 0.001 : c.max[ax] + r + 0.001
          hit = true
        }
      }
      return hit
    }
    const hx = axis('x', dx)
    const hz = axis('z', dz)
    const B = this.world.bounds
    p.x = THREE.MathUtils.clamp(p.x, -B, B)
    p.z = THREE.MathUtils.clamp(p.z, -B, B)
    return hx || hz
  }

  private groundAt(p: THREE.Vector3, r: number) {
    let g = 0
    for (const c of this.world.colliders) {
      if (c.max.y > p.y + STEP + 0.05 || c.max.y <= g) continue
      if (p.x + r > c.min.x && p.x - r < c.max.x && p.z + r > c.min.z && p.z - r < c.max.z) g = c.max.y
    }
    return g
  }

  // ------------------------------------------------------------------ fx
  private decal(point: THREE.Vector3, normal: THREE.Vector3) {
    const d = this.decals[this.decalIdx++ % this.decals.length]
    d.visible = true
    d.position.copy(point).addScaledVector(normal, 0.01)
    d.lookAt(this.tmp.copy(point).add(normal))
    d.rotateZ(Math.random() * Math.PI)
  }

  private puff(pool: THREE.Sprite[], key: 'spark' | 'blood', at: THREE.Vector3, n: number, life: number, normal?: THREE.Vector3) {
    for (let i = 0; i < n; i++) {
      const s = pool[this.poolIdx[key]++ % pool.length]
      s.visible = true
      s.position.copy(at)
      s.scale.setScalar(key === 'blood' ? 0.35 : 0.12)
      const vel = new THREE.Vector3((Math.random() - 0.5) * 3, Math.random() * 3, (Math.random() - 0.5) * 3)
      if (normal) vel.addScaledVector(normal, 3)
      this.fx.push({ obj: s, life, max: life, vel })
    }
  }

  private tracer(from: THREE.Vector3, to: THREE.Vector3, opacity: number) {
    const t = this.tracerPool[this.poolIdx.tracer++ % this.tracerPool.length]
    t.visible = true
    t.position.copy(from)
    t.lookAt(to)
    t.scale.set(1, 1, from.distanceTo(to))
    ;(t.material as THREE.MeshBasicMaterial).opacity = opacity
    this.fx.push({ obj: t, life: 0.06, max: 0.06 })
  }

  // ------------------------------------------------------------------ spawning
  private farNav(minDist: number, from: THREE.Vector3[]) {
    const nav = this.world.nav
    let best = nav[0]
    let bestScore = -1
    for (let i = 0; i < 30; i++) {
      const p = nav[Math.floor(Math.random() * nav.length)]
      const d = from.length ? Math.min(...from.map((f) => f.distanceTo(p))) : 999
      if (d >= minDist) return p.clone()
      if (d > bestScore) {
        bestScore = d
        best = p
      }
    }
    return best.clone()
  }

  private spawnPlayer() {
    const p = this.farNav(28, this.bots.filter((b) => b.alive).map((b) => b.pos))
    this.pos.copy(p)
    this.vel.set(0, 0, 0)
    this.yaw = Math.atan2(p.x, p.z) // face the centre of the market
    this.pitch = 0
    this.health = 100
    this.alive = true
    for (const g of this.guns) {
      g.ammo = g.stats.mag
      g.reserve = g.stats.reserve
    }
    this.reloadT = 0
    this.switchT = 0
    if (this.current !== 0) this.equip(0)
  }

  private spawnBot(b: Bot, minDist: number) {
    b.pos.copy(this.farNav(minDist, [this.pos]))
    b.health = 100
    b.alive = true
    b.lastSeen = null
    b.target = null
    b.seeT = 0
    b.canSee = false
    b.model.group.rotation.set(0, 0, 0)
    b.model.group.visible = true
    b.stuckFrom.copy(b.pos)
  }

  // ------------------------------------------------------------------ player
  private hurtPlayer(amount: number, from: Bot) {
    if (!this.alive) return
    this.health -= amount
    this.lastHurt = this.time
    this.audio.hurt()
    const to = this.tmp.subVectors(from.pos, this.pos)
    const ang = Math.atan2(-to.x, -to.z) - this.yaw
    this.cb.onDamage(ang)
    if (this.health <= 0) {
      this.health = 0
      this.alive = false
      this.deaths++
      this.streak = 0
      from.kills++
      this.respawnAt = this.time + 3.5
      this.trigger = false
      this.cb.onKillFeed({ id: ++this.feedId, killer: from.name, victim: 'You', weapon: 'OBJ-006', headshot: false, you: 'victim' })
    }
  }

  private updatePlayer(dt: number) {
    if (!this.alive) {
      if (this.time >= this.respawnAt) this.spawnPlayer()
      return
    }
    const k = this.keys
    const f = THREE.MathUtils.clamp((k.has('KeyW') ? 1 : 0) - (k.has('KeyS') ? 1 : 0) + this.touchMoveY, -1, 1)
    const s = THREE.MathUtils.clamp((k.has('KeyD') ? 1 : 0) - (k.has('KeyA') ? 1 : 0) + this.touchMoveX, -1, 1)
    const crouch = k.has('KeyC') || k.has('ControlLeft')
    this.crouchT = THREE.MathUtils.damp(this.crouchT, crouch ? 1 : 0, 12, dt)
    this.sprinting = k.has('ShiftLeft') && f > 0 && !crouch && this.reloadT <= 0 && !this.adsHeld && !this.trigger

    const stats = this.gun.stats
    let speed = 5.0 * (0.8 + stats.mobility / 250)
    if (this.sprinting) speed *= 1.55
    speed *= 1 - this.adsT * 0.45
    if (crouch) speed *= 0.55

    const fwd = this.tmp.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw))
    const right = this.tmp2.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw))
    const wish = new THREE.Vector3().addScaledVector(fwd, f).addScaledVector(right, s)
    if (wish.lengthSq() > 0) wish.normalize().multiplyScalar(speed)
    const accel = this.onGround ? 12 : 3
    this.vel.x = THREE.MathUtils.damp(this.vel.x, wish.x, accel, dt)
    this.vel.z = THREE.MathUtils.damp(this.vel.z, wish.z, accel, dt)
    this.vel.y -= GRAVITY * dt

    const h = crouch ? 1.2 : 1.8
    this.moveCircle(this.pos, this.vel.x * dt, this.vel.z * dt, PLAYER_R, h)
    this.pos.y += this.vel.y * dt
    // ceiling
    if (this.vel.y > 0) {
      for (const c of this.world.colliders) {
        if (c.min.y > this.pos.y + 1 && c.min.y < this.pos.y + h && this.pos.x + PLAYER_R > c.min.x && this.pos.x - PLAYER_R < c.max.x && this.pos.z + PLAYER_R > c.min.z && this.pos.z - PLAYER_R < c.max.z) {
          this.pos.y = c.min.y - h
          this.vel.y = 0
        }
      }
    }
    const g = this.groundAt(this.pos, PLAYER_R)
    if (this.pos.y <= g) {
      this.pos.y = g
      this.vel.y = 0
      this.onGround = true
    } else this.onGround = this.pos.y - g < 0.02

    // regen
    if (this.time - this.lastHurt > 4 && this.health < 100) this.health = Math.min(100, this.health + 30 * dt)

    // ADS
    const canAds = this.adsHeld && !this.sprinting && this.reloadT <= 0 && this.switchT <= 0
    const adsSpeed = 4 + stats.mobility / 18
    this.adsT = THREE.MathUtils.clamp(this.adsT + (canAds ? 1 : -1) * adsSpeed * dt, 0, 1)

    // weapon timers
    if (this.trigger && stats.auto) this.tryFire()
    this.bloom = Math.max(0, this.bloom - dt * stats.hipSpread * 3)
    this.kick = Math.max(0, this.kick - dt * 12)
    if (this.reloadT > 0) {
      this.reloadT -= dt
      if (this.reloadT <= 0) {
        const gun = this.gun
        const take = Math.min(gun.stats.mag - gun.ammo, gun.reserve)
        gun.ammo += take
        gun.reserve -= take
        this.reloadT = 0
      }
    }
    if (this.switchT > 0) {
      const before = this.switchT
      this.switchT -= dt
      if (before > 0.2 && this.switchT <= 0.2) this.equip(this.pendingSlot)
      if (this.switchT < 0) this.switchT = 0
    }

    const sp = Math.hypot(this.vel.x, this.vel.z)
    if (this.onGround) this.bob += dt * sp * (this.sprinting ? 1.6 : 1.9)
  }

  private updateCamera(dt: number) {
    const eye = THREE.MathUtils.lerp(1.65, 1.1, this.crouchT)
    const sp = Math.hypot(this.vel.x, this.vel.z)
    const bobAmt = this.onGround ? Math.min(1, sp / 6) * (1 - this.adsT * 0.85) : 0
    const deathDrop = this.alive ? 0 : 1.2
    this.camera.position.set(this.pos.x, this.pos.y + eye + Math.abs(Math.sin(this.bob)) * 0.05 * bobAmt - deathDrop, this.pos.z)
    this.camera.rotation.set(this.pitch + this.kick * 0.006, this.yaw, this.alive ? Math.sin(this.bob * 0.5) * 0.004 * bobAmt : 0.5)
    const zoom = this.currentZoom()
    const fov = (2 * Math.atan(Math.tan(THREE.MathUtils.degToRad(75 / 2)) / zoom) * 180) / Math.PI
    if (Math.abs(this.camera.fov - fov) > 0.01) {
      this.camera.fov = fov
      this.camera.updateProjectionMatrix()
    }

    // viewmodel
    const g = this.gun
    const ads = new THREE.Vector3(0, -g.model.sightY, -0.24 - (g.stats.class === 'pistol' ? 0.12 : 0))
    const t = this.adsT * this.adsT * (3 - 2 * this.adsT)
    const p = HIP.clone().lerp(ads, t)
    const bx = Math.sin(this.bob * 0.5) * 0.012 * bobAmt
    const by = Math.abs(Math.cos(this.bob * 0.5)) * 0.012 * bobAmt
    p.x += bx + this.sway.x * (1 - t * 0.8)
    p.y += -by + this.sway.y * (1 - t * 0.8)
    p.z += this.kick * 0.045
    const rot = new THREE.Euler(this.kick * 0.06, 0, 0)
    if (this.sprinting) {
      p.x += 0.04
      p.y -= 0.05
      rot.y += 0.55
      rot.x -= 0.15
    }
    if (this.reloadT > 0) {
      const k = Math.sin((1 - this.reloadT / this.reloadDur) * Math.PI)
      p.y -= k * 0.1
      rot.x -= k * 0.5
      rot.z += k * 0.4
    }
    if (this.switchT > 0) {
      const k = Math.sin((this.switchT / 0.4) * Math.PI)
      p.y -= k * 0.25
      rot.x -= k * 0.6
    }
    const vm = this.gunHolder
    vm.position.lerp(p, 1 - Math.exp(-28 * dt))
    vm.rotation.set(
      THREE.MathUtils.lerp(vm.rotation.x, rot.x, 1 - Math.exp(-18 * dt)),
      THREE.MathUtils.lerp(vm.rotation.y, rot.y, 1 - Math.exp(-12 * dt)),
      THREE.MathUtils.lerp(vm.rotation.z, rot.z, 1 - Math.exp(-12 * dt)),
    )
    this.sway.multiplyScalar(Math.exp(-8 * dt))
    vm.visible = this.alive && !this.isScoped()

    for (const gun of this.guns) if (gun.flash.visible && this.time - this.lastShot > 0.045) gun.flash.visible = false
    this.flashLight.intensity = Math.max(0, this.flashLight.intensity - dt * 120)
  }

  private isScoped() {
    return this.gun.stats.zoom >= 3.5 && this.adsT > 0.85
  }

  // ------------------------------------------------------------------ bots
  private updateBot(b: Bot, dt: number) {
    const m = b.model
    b.revealT = Math.max(0, b.revealT - dt)
    if (b.flashT > 0) {
      b.flashT -= dt
      if (b.flashT <= 0) b.flash.visible = false
    }
    if (!b.alive) {
      b.deadT += dt
      m.group.rotation.x = Math.max(-Math.PI / 2, -b.deadT * 5)
      if (b.deadT > 3) m.group.visible = false
      if (b.deadT > 5) this.spawnBot(b, 25)
      return
    }

    const eye = this.tmp.copy(b.pos).setY(b.pos.y + 1.6)
    const playerEye = this.camera.position
    const toP = new THREE.Vector3().subVectors(this.pos, b.pos)
    const dist = toP.length()

    b.nextLos -= dt
    if (b.nextLos <= 0) {
      b.nextLos = 0.2
      let see = false
      if (this.alive && dist < 75) {
        const fwd = new THREE.Vector3(-Math.sin(b.yaw), 0, -Math.cos(b.yaw))
        const facing = fwd.dot(toP.clone().setY(0).normalize())
        if (facing > 0.3 || dist < 10 || b.seeT > 0 || b.lastSeen) see = !this.blocked(eye.clone(), playerEye)
      }
      b.canSee = see
    }

    let moveX = 0
    let moveZ = 0
    let speed = 0
    if (b.canSee && this.alive) {
      b.seeT += dt
      b.lastSeen = this.pos.clone()
      const want = Math.atan2(-toP.x, -toP.z)
      b.yaw = lerpAngle(b.yaw, want, 1 - Math.exp(-10 * dt))
      b.strafeT -= dt
      if (b.strafeT <= 0) {
        b.strafe = Math.floor(Math.random() * 3) - 1
        b.strafeT = 0.6 + Math.random()
      }
      const rx = Math.cos(b.yaw)
      const rz = -Math.sin(b.yaw)
      speed = 2.2
      moveX = rx * b.strafe
      moveZ = rz * b.strafe
      if (dist > 30) {
        moveX += -Math.sin(b.yaw) * 0.8
        moveZ += -Math.cos(b.yaw) * 0.8
      }
      if (b.seeT > b.reaction && this.time >= b.nextShot) this.botShoot(b, dist)
      // aim arms at the player
      m.arms.rotation.x = Math.atan2(playerEye.y - 0.3 - (b.pos.y + 1.38), dist)
    } else {
      b.seeT = Math.max(0, b.seeT - dt * 2)
      m.arms.rotation.x = THREE.MathUtils.damp(m.arms.rotation.x, -0.2, 4, dt)
      const goal = b.lastSeen ?? b.target
      if (!goal || b.pos.distanceTo(goal) < 1.5) {
        if (b.lastSeen) b.lastSeen = null
        b.target = this.world.nav[Math.floor(Math.random() * this.world.nav.length)].clone()
      } else {
        const d = new THREE.Vector3().subVectors(goal, b.pos).setY(0).normalize()
        speed = b.lastSeen ? 3.6 : 2.3
        moveX = d.x
        moveZ = d.z
        b.yaw = lerpAngle(b.yaw, Math.atan2(-d.x, -d.z), 1 - Math.exp(-6 * dt))
      }
    }

    if (speed > 0 && (moveX || moveZ)) {
      const len = Math.hypot(moveX, moveZ) || 1
      const blockedMove = this.moveCircle(b.pos, (moveX / len) * speed * dt, (moveZ / len) * speed * dt, 0.35, 1.8)
      b.walk += dt * speed * 2.2
      b.stuckT += dt
      if (b.stuckT > 1.5) {
        if (b.pos.distanceTo(b.stuckFrom) < 0.5 || blockedMove) {
          b.target = this.world.nav[Math.floor(Math.random() * this.world.nav.length)].clone()
          b.lastSeen = null
        }
        b.stuckT = 0
        b.stuckFrom.copy(b.pos)
      }
    }
    // keep a little personal space from the player
    if (dist < 0.8 && dist > 0.001) b.pos.addScaledVector(toP, -(0.8 - dist) / dist)
    b.pos.y = this.groundAt(b.pos, 0.3)

    const swing = speed > 0 ? Math.sin(b.walk) * 0.6 : 0
    m.legs[0].rotation.x = swing
    m.legs[1].rotation.x = -swing
    m.group.position.copy(b.pos)
    m.group.rotation.y = b.yaw
  }

  private botShoot(b: Bot, dist: number) {
    if (b.burstLeft <= 0) b.burstLeft = 3 + Math.floor(Math.random() * 3)
    b.burstLeft--
    b.nextShot = this.time + (b.burstLeft > 0 ? 0.11 : 0.7 + Math.random() * 0.7)
    b.revealT = 2.5
    b.flash.visible = true
    b.flashT = 0.05
    const tip = new THREE.Vector3()
    ;(b.model.gun.userData.tip as THREE.Object3D).getWorldPosition(tip)
    const movingPenalty = this.sprinting ? 0.55 : this.moving() ? 0.8 : 1
    const crouchBonus = this.crouchT > 0.5 ? 0.8 : 1
    const p = this.diff.acc * THREE.MathUtils.clamp(1 - dist / 85, 0.15, 1) * movingPenalty * crouchBonus
    const target = this.camera.position.clone().add(new THREE.Vector3(0, -0.3, 0))
    if (Math.random() < p) {
      this.hurtPlayer(this.diff.dmg * (0.85 + Math.random() * 0.3), b)
    } else {
      target.add(new THREE.Vector3((Math.random() - 0.5) * 2.5, (Math.random() - 0.5) * 1.5, (Math.random() - 0.5) * 2.5))
    }
    if (Math.random() < 0.5) this.tracer(tip, target, 0.7)
    const vol = THREE.MathUtils.clamp(1 - dist / 90, 0.08, 0.7)
    this.audio.shot('ar', false, vol, Math.min(1, dist / 60))
  }

  // ------------------------------------------------------------------ match
  private endMatch() {
    if (this.ended) return
    this.ended = true
    const rows = this.board()
    const placement = rows.findIndex((r) => r.you) + 1
    const naira = this.score * 12 + (placement === 1 ? 15000 : 0)
    this.cb.onEnd({
      kills: this.kills,
      deaths: this.deaths,
      headshots: this.headshots,
      accuracy: this.shots ? Math.round((this.hits / this.shots) * 100) : 0,
      score: this.score,
      bestStreak: this.bestStreak,
      naira,
      xp: this.score * 2 + 500,
      placement,
      players: rows.length,
      seconds: Math.round(this.elapsed),
    })
    if (document.pointerLockElement) document.exitPointerLock()
  }

  private board(): BoardRow[] {
    return [{ name: 'You', kills: this.kills, deaths: this.deaths, you: true }, ...this.bots.map((b) => ({ name: b.name, kills: b.kills, deaths: b.deaths, you: false }))].sort(
      (a, b) => b.kills - a.kills || a.deaths - b.deaths,
    )
  }

  private drawMinimap() {
    const c = this.minimap
    const ctx = c.getContext('2d')
    if (!ctx) return
    const W = c.width
    const scale = W / 70
    ctx.clearRect(0, 0, W, W)
    ctx.save()
    ctx.beginPath()
    ctx.arc(W / 2, W / 2, W / 2 - 2, 0, Math.PI * 2)
    ctx.clip()
    ctx.fillStyle = 'rgba(16,22,18,0.82)'
    ctx.fillRect(0, 0, W, W)
    ctx.translate(W / 2, W / 2)
    ctx.rotate(this.yaw)
    ctx.translate(-this.pos.x * scale, -this.pos.z * scale)
    ctx.fillStyle = 'rgba(70,64,56,0.9)'
    ctx.fillRect(-7 * scale, -75 * scale, 14 * scale, 150 * scale)
    ctx.fillRect(-75 * scale, 27 * scale, 150 * scale, 10 * scale)
    for (const b of this.world.colliders) {
      const h = b.max.y - b.min.y
      ctx.fillStyle = h > 2.5 ? 'rgba(170,180,165,0.75)' : 'rgba(120,130,115,0.55)'
      ctx.fillRect(b.min.x * scale, b.min.z * scale, (b.max.x - b.min.x) * scale, (b.max.z - b.min.z) * scale)
    }
    for (const b of this.bots) {
      if (!b.alive) continue
      if (b.revealT <= 0 && b.pos.distanceTo(this.pos) > 9) continue
      ctx.fillStyle = '#ff3b30'
      ctx.beginPath()
      ctx.arc(b.pos.x * scale, b.pos.z * scale, 4 * (W / 180), 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()
    // player arrow + view cone
    ctx.save()
    ctx.translate(W / 2, W / 2)
    const cone = ctx.createRadialGradient(0, 0, 0, 0, 0, W / 2)
    cone.addColorStop(0, 'rgba(255,255,255,0.22)')
    cone.addColorStop(1, 'rgba(255,255,255,0)')
    ctx.fillStyle = cone
    ctx.beginPath()
    ctx.moveTo(0, 0)
    ctx.arc(0, 0, W / 2, -Math.PI / 2 - 0.6, -Math.PI / 2 + 0.6)
    ctx.fill()
    const s = W / 180
    ctx.fillStyle = '#3ddc84'
    ctx.beginPath()
    ctx.moveTo(0, -8 * s)
    ctx.lineTo(6 * s, 6 * s)
    ctx.lineTo(0, 3 * s)
    ctx.lineTo(-6 * s, 6 * s)
    ctx.closePath()
    ctx.fill()
    ctx.restore()
    ctx.strokeStyle = 'rgba(61,220,132,0.5)'
    ctx.lineWidth = 2 * s
    ctx.beginPath()
    ctx.arc(W / 2, W / 2, W / 2 - 2, 0, Math.PI * 2)
    ctx.stroke()
  }

  // ------------------------------------------------------------------ loop
  private frame() {
    const dt = Math.min(this.clock.getDelta(), 0.05)
    const running = this.locked && !this.ended
    this.time += dt
    if (running) {
      this.elapsed += dt
      this.updatePlayer(dt)
      for (const b of this.bots) this.updateBot(b, dt)
      if (this.elapsed >= MATCH_SECONDS) this.endMatch()
    }
    this.world.update(dt, this.time)
    this.updateCamera(dt)

    for (let i = this.fx.length - 1; i >= 0; i--) {
      const f = this.fx[i]
      f.life -= dt
      if (f.vel) {
        f.vel.y -= 9 * dt
        f.obj.position.addScaledVector(f.vel, dt)
      }
      const mat = (f.obj as THREE.Mesh).material as THREE.Material & { opacity: number }
      if (f.obj instanceof THREE.Sprite) mat.opacity = Math.max(0, f.life / f.max)
      if (f.life <= 0) {
        f.obj.visible = false
        this.fx.splice(i, 1)
      }
    }

    const r = this.renderer
    r.clear()
    r.render(this.scene, this.camera)
    r.clearDepth()
    r.render(this.vmScene, this.vmCamera)

    this.hudTimer -= dt
    if (this.hudTimer <= 0) {
      this.hudTimer = 1 / 15
      const g = this.gun
      this.cb.onHud({
        health: Math.round(this.health),
        ammo: g.ammo,
        reserve: g.reserve,
        mag: g.stats.mag,
        weaponName: g.stats.name,
        weaponNick: g.stats.nickname,
        slot: this.current,
        reloading: this.reloadT > 0 ? 1 - this.reloadT / this.reloadDur : 0,
        kills: this.kills,
        deaths: this.deaths,
        score: this.score,
        streak: this.streak,
        timeLeft: Math.max(0, MATCH_SECONDS - this.elapsed),
        spread: this.spread(),
        scoped: this.isScoped(),
        ads: this.adsT,
        alive: this.alive,
        respawnIn: Math.max(0, this.respawnAt - this.time),
        board: this.board(),
        showBoard: this.showBoard,
      })
    }
    this.mapTimer -= dt
    if (this.mapTimer <= 0) {
      this.mapTimer = 1 / 15
      this.drawMinimap()
    }
  }
}

function lerpAngle(a: number, b: number, t: number) {
  let d = b - a
  while (d > Math.PI) d -= Math.PI * 2
  while (d < -Math.PI) d += Math.PI * 2
  return a + d * t
}
