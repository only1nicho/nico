import type { WeaponClass } from '@/data/game'

/** Procedural combat audio — no sample downloads, every sound is synthesised with WebAudio. */
export class GameAudio {
  ctx: AudioContext | null = null
  private master!: GainNode
  private noise!: AudioBuffer

  init() {
    if (this.ctx) {
      void this.ctx.resume()
      return
    }
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    this.ctx = new Ctx()
    this.master = this.ctx.createGain()
    this.master.gain.value = 0.5
    const comp = this.ctx.createDynamicsCompressor()
    this.master.connect(comp).connect(this.ctx.destination)
    const len = this.ctx.sampleRate * 0.6
    this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate)
    const d = this.noise.getChannelData(0)
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1
  }

  private env(g: GainNode, t: number, peak: number, decay: number) {
    g.gain.setValueAtTime(0.0001, t)
    g.gain.exponentialRampToValueAtTime(peak, t + 0.004)
    g.gain.exponentialRampToValueAtTime(0.0001, t + decay)
  }

  /** volume 0-1, muffle 0-1 (distance) */
  shot(cls: WeaponClass, suppressed = false, volume = 1, muffle = 0) {
    const ctx = this.ctx
    if (!ctx || volume < 0.01) return
    const t = ctx.currentTime
    const heavy = cls === 'sniper' || cls === 'dmr' || cls === 'lmg'
    const decay = suppressed ? 0.12 : heavy ? 0.45 : cls === 'pistol' || cls === 'smg' ? 0.2 : 0.3

    const src = ctx.createBufferSource()
    src.buffer = this.noise
    const lp = ctx.createBiquadFilter()
    lp.type = 'lowpass'
    lp.frequency.value = (suppressed ? 1400 : heavy ? 3200 : 4500) * (1 - muffle * 0.8)
    const g = ctx.createGain()
    this.env(g, t, (suppressed ? 0.35 : 1) * volume, decay)
    src.connect(lp).connect(g).connect(this.master)
    src.start(t)
    src.stop(t + decay + 0.05)

    // low-end thump
    const o = ctx.createOscillator()
    o.type = 'sine'
    o.frequency.setValueAtTime(heavy ? 120 : 160, t)
    o.frequency.exponentialRampToValueAtTime(40, t + 0.15)
    const og = ctx.createGain()
    this.env(og, t, (suppressed ? 0.2 : 0.8) * volume, 0.18)
    o.connect(og).connect(this.master)
    o.start(t)
    o.stop(t + 0.2)
  }

  hit(head: boolean, kill: boolean) {
    const ctx = this.ctx
    if (!ctx) return
    const t = ctx.currentTime
    const o = ctx.createOscillator()
    o.type = 'triangle'
    o.frequency.value = kill ? 520 : head ? 1600 : 1100
    const g = ctx.createGain()
    this.env(g, t, kill ? 0.5 : 0.25, kill ? 0.25 : 0.07)
    o.connect(g).connect(this.master)
    o.start(t)
    o.stop(t + 0.3)
  }

  click(pitch = 1, delay = 0) {
    const ctx = this.ctx
    if (!ctx) return
    const t = ctx.currentTime + delay
    const src = ctx.createBufferSource()
    src.buffer = this.noise
    const bp = ctx.createBiquadFilter()
    bp.type = 'bandpass'
    bp.frequency.value = 2500 * pitch
    bp.Q.value = 6
    const g = ctx.createGain()
    this.env(g, t, 0.5, 0.05)
    src.connect(bp).connect(g).connect(this.master)
    src.start(t)
    src.stop(t + 0.08)
  }

  hurt() {
    const ctx = this.ctx
    if (!ctx) return
    const t = ctx.currentTime
    const o = ctx.createOscillator()
    o.type = 'sawtooth'
    o.frequency.setValueAtTime(140, t)
    o.frequency.exponentialRampToValueAtTime(60, t + 0.2)
    const lp = ctx.createBiquadFilter()
    lp.frequency.value = 400
    const g = ctx.createGain()
    this.env(g, t, 0.3, 0.22)
    o.connect(lp).connect(g).connect(this.master)
    o.start(t)
    o.stop(t + 0.25)
  }

  dispose() {
    void this.ctx?.close()
    this.ctx = null
  }
}
