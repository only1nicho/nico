# Operation Naira

A browser-based tactical first-person shooter set in Nigeria, in the vein of Call of Duty Mobile. You can play a training match in Oshodi Market, Lagos, today. Online multiplayer, weapon progression and voice chat are on the roadmap.

**Tech:** TanStack Start (React 19), Three.js, Tailwind CSS 4, Vite 7, deployed on Netlify. The key art was generated with Gemini through Netlify AI Gateway and is served through the Netlify Image CDN.

## Run locally
```bash
pnpm install
netlify dev   # or: pnpm dev
```
Open `/play`, click **Deploy** and fight. Controls: WASD to move, mouse to aim, left-click to fire, right-click to aim down sights, R to reload, Shift to sprint, C to crouch, 1/2 to swap weapons, Tab for scores.

## Roadmap
See [PLAN.md](PLAN.md). Next up: the Armory page, then accounts, persistent progression, real-time multiplayer and voice chat.


## Mobile touch controls

The `/play` game now includes coarse-pointer touch controls:
- Left virtual joystick for movement
- Drag on the right-side look area to aim
- Hold FIRE for continuous fire (for automatic weapons)
- Hold AIM for aiming down sights
- RELOAD, SWAP, and JUMP action buttons

Desktop keyboard/mouse controls remain in place. On a phone, tap DEPLOY to enter the match; pointer lock is bypassed for touch devices.
